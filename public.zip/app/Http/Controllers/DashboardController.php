<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\Booking;
use App\Models\Wallet;

class DashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        $totalBookings = Booking::where('user_id', $user->id)->count();
        $wallet = Wallet::where('user_id', $user->id)->first();
        $recentBookings = Booking::where('user_id', $user->id)
            ->with(['flightBooking'])
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard.index', compact('totalBookings', 'wallet', 'recentBookings'));
    }

    public function bookings()
    {
        // Try with flightBooking relationship if exists
        $query = Booking::where('user_id', Auth::id())->latest();
        if (method_exists(Booking::class, 'flightBooking')) {
            $query->with('flightBooking');
        }
        $bookings = $query->get();
        return view('dashboard.bookings', compact('bookings'));
    }

    public function profile()
    {
        return view('dashboard.profile', ['user' => Auth::user()]);
    }

    public function updateProfile(Request $request)
    {
        $user = Auth::user();
        $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'nullable|string|max:20',
            'address' => 'nullable|string'
        ]);

        $user->name = $request->name;
        $user->phone = $request->phone;
        $user->address = $request->address;
        $user->save();

        return redirect()->back()->with('success', 'Profile updated successfully.');
    }

    public function wallet()
    {
        $user = Auth::user();
        $wallet = Wallet::firstOrCreate(['user_id' => $user->id], ['balance' => 0]);
        $transactions = $user->transactions()->latest()->take(10)->get();
        return view('dashboard.wallet', compact('wallet', 'transactions'));
    }

    public function wishlist()
    {
        $wishlistItems = \App\Models\Wishlist::where('user_id', Auth::id())->latest()->get();
        return view('dashboard.wishlist', compact('wishlistItems'));
    }

    public function searches()
    {
        $savedSearches = \App\Models\SavedSearch::where('user_id', Auth::id())->latest()->get();
        return view('dashboard.searches', compact('savedSearches'));
    }

    public function notifications()
    {
        $notifications = Auth::user()->notifications()->latest()->paginate(10);
        Auth::user()->unreadNotifications->markAsRead();
        return view('dashboard.notifications', compact('notifications'));
    }

    public function priceAlerts()
    {
        $alerts = \App\Models\FareAlert::where('agent_id', Auth::id())->latest()->get();
        return view('dashboard.price-alerts', compact('alerts'));
    }

    public function settings()
    {
        return view('dashboard.settings');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|min:8|confirmed',
        ]);

        $user = Auth::user();

        if (!\Hash::check($request->current_password, $user->password)) {
            return back()->with('error', 'Current password does not match.');
        }

        $user->update(['password' => \Hash::make($request->new_password)]);

        return back()->with('success', 'Password updated successfully!');
    }

    public function updateSettings(Request $request)
    {
        // Simple placeholder for preference update
        return back()->with('success', 'Notification preferences saved!');
    }
}
