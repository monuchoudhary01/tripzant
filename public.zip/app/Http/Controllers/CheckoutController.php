<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Booking;
use App\Services\AuditLogService;
use App\Services\PricingService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class CheckoutController extends Controller
{
    public function index(Request $request)
    {
        $type = $request->input('type', 'flight');
        $id = $request->input('id', $request->input('amp;id')); // Fix for &amp; in URL
        $item = null;

        if ($type === 'flight') {
            $flightResults = Cache::get('flight_search_full');
            if ($flightResults) {
                $item = $flightResults['data'][0] ?? null; 
            }
        } elseif ($type === 'homestay') {
            $item = \App\Models\Homestay::find($id);
        } elseif ($type === 'tour') {
            $item = \App\Models\Tour::find($id);
        } elseif ($type === 'esim') {
            $item = \App\Models\EsimPlan::find($id);
        } elseif ($type === 'insurance') {
            $item = \App\Models\InsurancePlan::find($id);
        }

        return view('checkout', compact('type', 'item'));
    }

    public function process(Request $request)
    {
        // Handle Mandatory Profile Update
        if ($request->has('profile_update')) {
            $user = Auth::user();
            $upData = $request->input('profile_update');
            if ($user && isset($upData['name']) && isset($upData['phone'])) {
                $user->update([
                    'name' => $upData['name'],
                    'phone' => $upData['phone']
                ]);
            }
        }

        $type = $request->input('type', 'flight');
        $sellingPrice = $request->input('selling_price', 0);

        $booking = Booking::create([
            'user_id' => Auth::id(),
            'booking_reference' => strtoupper($type) . '-' . strtoupper(bin2hex(random_bytes(4))),
            'type' => $type,
            'total_amount' => $sellingPrice,
            'currency' => 'INR',
            'status' => 'pending',
            'api_booking_details' => json_encode($request->except(['_token']))
        ]);

        // Create Booking Item
        \App\Models\BookingItem::create([
            'booking_id' => $booking->id,
            'item_name' => $request->input('item_name', ucfirst($type) . ' Booking'),
            'item_type' => $type,
            'amount' => $sellingPrice,
            'details' => json_encode($request->input('item_details', []))
        ]);

        AuditLogService::log('BOOKING', 'PROCESS', "Checkout processed for {$booking->booking_reference}", $request->all());

        // Process Affiliate Commission
        \App\Services\CommissionService::processBookingCommission($booking);

        return response()->json([
            'success' => true, 
            'message' => 'Booking initiated successfully!', 
            'redirect' => route('booking.confirmation', ['id' => $booking->booking_reference])
        ]);
    }
}
