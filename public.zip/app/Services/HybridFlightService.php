<?php

namespace App\Services;

use App\Proxy\Flight\Providers\AmadeusProvider;
use App\Proxy\Flight\Providers\RapidAPIProvider;
use App\Proxy\Flight\Providers\ScraperProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class HybridFlightService
{
    protected $providers = [];
    protected $pricingService;

    public function __construct(
        AmadeusProvider $amadeus,
        RapidAPIProvider $rapid,
        ScraperProvider $scraper,
        PricingService $pricingService
    ) {
        $configs = \App\Models\ApiConfig::where('api_type', 'flight')->where('is_active', true)->get();
        
        $availableProviders = [
            'amadeus' => $amadeus,
            'rapidapi' => $rapid,
            'scraper' => $scraper
        ];

        foreach ($configs as $config) {
            if (isset($availableProviders[$config->provider_name])) {
                $this->providers[$config->provider_name] = $availableProviders[$config->provider_name];
            }
        }

        $this->pricingService = $pricingService;
    }

    /**
     * Unified Hybrid Search
     */
    public function search(array $params)
    {
        $allResults = [];
        $cheapestFare = PHP_INT_MAX;
        $bestDeal = null;

        foreach ($this->providers as $name => $provider) {
            $results = $provider->search($params);
            
            foreach ($results as $flight) {
                // Apply Pricing Logic based on User Role
                $pricing = $this->pricingService->calculateSellingPrice($flight->net_price, 'flight');
                $flight->price = $pricing['selling_price'];
                
                // Add price comparison metadata
                $flight->markup_value = $pricing['markup'];
                
                $allResults[] = $flight;

                // Track Cheapest
                if ($flight->price < $cheapestFare) {
                    $cheapestFare = $flight->price;
                    $bestDeal = $flight;
                }
            }
        }

        // Tag the Cheapest Flight as "Best Deal"
        if ($bestDeal) {
            foreach ($allResults as $f) {
                if ($f->id === $bestDeal->id && $f->source === $bestDeal->source) {
                    $f->is_cheapest = true;
                }
            }
        }

        // Sort by price ascending
        usort($allResults, function($a, $b) {
            return $a->price <=> $b->price;
        });

        return [
            'success' => true,
            'total' => count($allResults),
            'currency' => 'INR',
            'data' => $allResults,
        ];
    }
}
