<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TravelPayoutsFlightService
{
    protected $token;
    protected $marker;

    public function __construct()
    {
        $this->token = config('services.travelpayouts.token');
        $this->marker = config('services.travelpayouts.marker');
    }

    public function search($params)
    {
        $origin = $params['from'] ?? 'DEL';
        $destination = $params['to'] ?? 'BOM';
        $date = $params['date'] ?? date('Y-m-d', strtotime('+7 days'));
        
        $month = substr($date, 0, 7);

        $flights = [];

        // 1. Fetch Month Matrix
        $resMatrix = Http::get("https://api.travelpayouts.com/v2/prices/month-matrix", [
            'origin' => $origin,
            'destination' => $destination,
            'month' => $month,
            'show_to_affiliates' => 'true',
            'token' => $this->token,
            'currency' => 'usd'
        ]);

        if ($resMatrix->successful() && isset($resMatrix['data'])) {
            foreach ($resMatrix['data'] as $f) {
                if ($f['depart_date'] == $date) {
                    $flights[] = $this->formatFlight($f, $origin, $destination, $date);
                }
            }
        }

        // 2. Fetch Latest Prices
        $resLatest = Http::get("https://api.travelpayouts.com/v2/prices/latest", [
            'origin' => $origin,
            'destination' => $destination,
            'beginning_of_period' => $date,
            'period_type' => 'month',
            'show_to_affiliates' => 'true',
            'token' => $this->token,
            'currency' => 'usd'
        ]);

        if ($resLatest->successful() && isset($resLatest['data'])) {
            foreach ($resLatest['data'] as $f) {
                if ($f['depart_date'] == $date) {
                    $flights[] = $this->formatFlight($f, $origin, $destination, $date);
                }
            }
        }
        
        // 3. Fetch Cheap
        $resCheap = Http::get("https://api.travelpayouts.com/v1/prices/cheap", [
            'origin' => $origin,
            'destination' => $destination,
            'depart_date' => $month, 
            'token' => $this->token,
            'currency' => 'usd'
        ]);

        if ($resCheap->successful() && isset($resCheap['data'][$destination])) {
            foreach ($resCheap['data'][$destination] as $f) {
                $f_date = substr($f['departure_at'], 0, 10);
                if ($f_date == $date) {
                    $flights[] = $this->formatCheapFlight($f, $origin, $destination, $f['departure_at']);
                }
            }
        }

        // If no flights found exactly on date, fetch backup from matrix to at least show something
        if (empty($flights) && isset($resMatrix['data'])) {
            foreach (array_slice($resMatrix['data'], 0, 5) as $f) {
                $flights[] = $this->formatFlight($f, $origin, $destination, $f['depart_date'] ?? $date);
            }
        }

        // Deduplicate using unique key
        $uniqueFlights = [];
        foreach ($flights as $f) {
            $key = $f['flight_number'] . '_' . $f['price'] . '_' . $f['departure_at'];
            $uniqueFlights[$key] = $f;
        }

        // Sort by price
        usort($uniqueFlights, function($a, $b) {
            return $a['price'] <=> $b['price'];
        });

        return [
            'data' => array_values($uniqueFlights),
            'raw_data' => array_values($uniqueFlights)
        ];
    }

    protected function formatFlight($data, $origin, $destination, $date)
    {
        $price = (float)($data['value'] ?? 100);
        $airlineCode = !empty($data['gate']) ? strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $data['gate']), 0, 2)) : 'XX';
        if(empty($airlineCode) || strlen($airlineCode) < 2) $airlineCode = 'TP';
        
        return [
            'id' => md5(json_encode($data) . time() . rand(1, 1000)),
            'airline_code' => $airlineCode,
            'airline' => !empty($data['gate']) ? $data['gate'] : 'TravelPayouts Partner',
            'flight_number' => rand(100, 9999), 
            'departure_at' => $date . 'T' . str_pad(rand(6, 20), 2, '0', STR_PAD_LEFT) . ':00:00Z',
            'arrival_at' => $date . 'T' . str_pad(rand(6, 23), 2, '0', STR_PAD_LEFT) . ':00:00Z',
            'price' => $price,
            'net_price' => $price * 0.95,
            'currency' => 'USD',
            'number_of_changes' => $data['number_of_changes'] ?? 0,
            'duration' => $this->formatDuration($data['duration'] ?? 120),
            'fare_class' => 'E',
            'cabin' => 'ECONOMY',
            'baggage' => '15',
            'baggage_unit' => 'KG',
            'is_refundable' => true,
            'terminal' => '1',
            'seats' => 9,
            'gds_id' => md5(json_encode($data)),
            'source' => 'travelpayouts',
            'booking_link' => "https://search.travelpayouts.com/flights/?origin={$origin}&destination={$destination}&depart_date={$date}&marker={$this->marker}"
        ];
    }

    protected function formatCheapFlight($data, $origin, $destination, $departure_at)
    {
        $price = (float)($data['price'] ?? 100);
        $airlineCode = $data['airline'] ?? 'XX';
        $date = substr($departure_at, 0, 10);
        
        return [
            'id' => md5(json_encode($data) . time() . rand(1, 1000)),
            'airline_code' => $airlineCode,
            'airline' => $this->getAirlineName($airlineCode),
            'flight_number' => $data['flight_number'] ?? rand(100, 9999), 
            'departure_at' => $departure_at,
            'arrival_at' => $data['return_at'] ?? $departure_at,
            'price' => $price,
            'net_price' => $price * 0.95,
            'currency' => 'USD',
            'number_of_changes' => 0,
            'duration' => $this->formatDuration($data['duration'] ?? 120),
            'fare_class' => 'E',
            'cabin' => 'ECONOMY',
            'baggage' => '15',
            'baggage_unit' => 'KG',
            'is_refundable' => true,
            'terminal' => '1',
            'seats' => 9,
            'gds_id' => md5(json_encode($data)),
            'source' => 'travelpayouts',
            'booking_link' => "https://search.travelpayouts.com/flights/?origin={$origin}&destination={$destination}&depart_date={$date}&marker={$this->marker}"
        ];
    }

    public function formatDuration($minutes)
    {
        if(!$minutes) return '2h 00m';
        $h = floor($minutes / 60);
        $m = $minutes % 60;
        return "{$h}h {$m}m";
    }

    public function getAirlineName($code)
    {
        $airlines = [
            '6E' => 'IndiGo', 'UK' => 'Vistara', 'AI' => 'Air India',
            'SG' => 'SpiceJet', 'QP' => 'Akasa Air', 'IX' => 'Air India Express',
            'I5' => 'AirAsia India', 'G8' => 'Go First', 'AA' => 'American Airlines',
            'EK' => 'Emirates', 'QR' => 'Qatar Airways', 'EY' => 'Etihad',
            'SQ' => 'Singapore Airlines', 'LH' => 'Lufthansa', 'AF' => 'Air France',
            'BA' => 'British Airways', 'DL' => 'Delta Airlines', 'UA' => 'United Airlines',
        ];
        return $airlines[$code] ?? $code;
    }
}
