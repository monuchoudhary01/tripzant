<?php

namespace App\Proxy\Flight\Providers;

use App\Proxy\Flight\FlightProvider;
use App\Proxy\Flight\UnifiedFlight;

class RapidAPIProvider implements FlightProvider
{
    public function getName(): string { return 'rapidapi'; }
    public function supportsBooking(): bool { return true; }

    public function search(array $params): array
    {
        // Simulate a secondary API call
        $unified = [];
        $airlines = ['6E' => 'IndiGo', 'AI' => 'Air India'];
        
        foreach (['6E', 'AI'] as $code) {
            $basePrice = rand(4000, 6000);
            $unified[] = new UnifiedFlight([
                'id' => 'rapid_' . rand(100, 999),
                'airline_code' => $code,
                'airline_name' => $airlines[$code],
                'flight_number' => 'R-' . rand(100, 999),
                'departure_at' => ($params['date'] ?? date('Y-m-d')) . 'T08:00:00',
                'arrival_at' => ($params['date'] ?? date('Y-m-d')) . 'T10:00:00',
                'departure_city' => $params['from'] ?? 'DEL',
                'arrival_city' => $params['to'] ?? 'BOM',
                'duration' => '2h 0m',
                'stops' => 0,
                'price' => (float) $basePrice,
                'net_price' => (float) $basePrice,
                'currency' => 'INR',
                'cabin' => 'ECONOMY',
                'baggage' => '15',
                'baggage_unit' => 'KG',
                'terminal' => 'T2',
                'source' => 'rapidapi',
                'raw_data' => []
            ]);
        }

        return $unified;
    }
}
