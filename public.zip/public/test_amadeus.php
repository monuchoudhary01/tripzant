<?php

/**
 * Amadeus API Connection Test Script
 * This script tests the API credentials provided in the .env file.
 */

// 1. Boot Laravel to leverage existing services and configuration
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Http\Kernel::class);
$response = $kernel->handle(
    $request = Illuminate\Http\Request::capture()
);

use App\Services\AmadeusService;
use Illuminate\Support\Facades\Config;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Amadeus API Test | TripZant</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --success: #10b981;
            --error: #ef4444;
            --bg: #0f172a;
            --card: #1e293b;
            --text: #f8fafc;
        }
        body {
            font-family: 'Outfit', sans-serif;
            background-color: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .container {
            max-width: 900px;
            width: 100%;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
            animation: fadeInDown 0.8s ease-out;
        }
        h1 { font-size: 2.5rem; margin: 0; background: linear-gradient(90deg, #818cf8, #c084fc); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .card {
            background: var(--card);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            border: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 24px;
            transition: transform 0.3s ease;
        }
        .card:hover { transform: translateY(-5px); }
        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 12px;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 600;
        }
        .status-success { background: rgba(16, 185, 129, 0.1); color: var(--success); }
        .status-error { background: rgba(239, 68, 68, 0.1); color: var(--error); }
        .key-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .info-item {
            background: rgba(255, 255, 255, 0.05);
            padding: 15px;
            border-radius: 12px;
        }
        .info-label { font-size: 0.75rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; }
        .info-value { font-size: 1rem; font-weight: 600; margin-top: 5px; overflow: hidden; text-overflow: ellipsis; }
        pre {
            background: #000;
            padding: 20px;
            border-radius: 8px;
            overflow-x: auto;
            font-size: 0.875rem;
            color: #d1d5db;
            border: 1px solid #334155;
            max-height: 400px;
        }
        .step-title { display: flex; align-items: center; gap: 10px; margin-bottom: 15px; }
        .step-number {
            width: 24px;
            height: 24px;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.75rem;
            font-weight: 700;
        }
        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .copy-box {
            background: rgba(0, 0, 0, 0.3);
            border: 1px dashed var(--primary);
            padding: 15px;
            margin-top: 10px;
            cursor: pointer;
            position: relative;
        }
        .copy-box:hover { background: rgba(0, 0, 0, 0.5); }
    </style>
    <script>
        function copyToClipboard(elementId) {
            const text = document.getElementById(elementId).innerText;
            navigator.clipboard.writeText(text).then(() => {
                alert('Copied to clipboard!');
            });
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Amadeus API Diagnostics</h1>
            <p style="color: #94a3b8; margin-top: 10px;">Verifying real-time data connectivity for TripZant</p>
        </div>

        <div class="card">
            <h2 class="step-title"><span class="step-number">1</span> Configuration Check</h2>
            <div class="key-info">
                <div class="info-item">
                    <div class="info-label">API KEY</div>
                    <div class="info-value"><?php echo config('tripzant.amadeus.key') ?: '<span style="color:var(--error)">MISSING</span>'; ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Environment</div>
                    <div class="info-value"><?php echo config('tripzant.amadeus.env'); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Base URL</div>
                    <div class="info-value" style="font-size: 0.875rem;"><?php echo config('tripzant.amadeus.base_url'); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Local Time (UTC)</div>
                    <div class="info-value" style="font-size: 0.875rem;"><?php echo gmdate('Y-m-d H:i:s'); ?>Z</div>
                </div>
            </div>
        </div>

        <?php
        try {
            $service = new AmadeusService();
            
            // Step 2: Authentication
            echo '<div class="card">';
            echo '<h2 class="step-title"><span class="step-number">2</span> Authentication Test</h2>';
            
            $token = $service->getAccessToken();
            
            if ($token) {
                echo '<div class="status-badge status-success">✓ Token Generated Successfully</div>';
                echo '<p style="margin-top: 15px; font-size: 0.875rem;">Short Token: <code style="color: var(--primary)">' . substr($token, 0, 15) . '...</code></p>';
                
                // Step 3: API Request
                echo '</div><div class="card">';
                echo '<h2 class="step-title"><span class="step-number">3</span> Flight Offers Search (Live Data)</h2>';
                echo '<p style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 20px;">Fetching flights from Madrid (MAD) to Barcelona (BCN)...</p>';
                
                $results = $service->flightOffersSearch([
                    'originLocationCode' => 'MAD',
                    'destinationLocationCode' => 'BCN',
                    'departureDate' => date('Y-m-d', strtotime('+3 weeks')),
                    'adults' => 1,
                    'max' => 1
                ]);

                if (isset($results['error']) && $results['error']) {
                    echo '<div class="status-badge status-error">✕ Flight Search Failed (Upstream API)</div>';
                    echo '<p style="color: var(--error); margin: 15px 0;">' . $results['message'] . '</p>';
                    echo '<div class="info-item" style="margin-top:10px; border: 1px solid rgba(239, 68, 68, 0.3);">';
                    echo '<div class="info-label">Diagnostic Info for Amadeus Support</div>';
                    echo '<div class="info-value" style="font-family: monospace; font-size: 0.85rem; color: #fca5a5; margin-top: 5px;">';
                    echo 'Timestamp: ' . gmdate('Y-m-d\TH:i:s\Z') . '<br>';
                    echo 'Ama-Client-Ref: [See Server Logs] <br>';
                    echo 'Endpoint: /v2/shopping/flight-offers';
                    echo '</div>';
                    echo '</div>';
                } else {
                    $count = count($results['data'] ?? []);
                    echo '<div class="status-badge status-success">✓ Flight Data Received</div>';
                    echo '<p style="margin-top: 15px;">Success! Found <strong>' . $count . '</strong> flight options.</p>';
                    echo '<p style="font-size: 0.75rem; color: #94a3b8;">Correlation ID (Ama-Client-Ref) has been logged to the database and <code>storage/logs/laravel.log</code></p>';
                }

                // Step 4: Location Search (More stable in Test env)
                echo '</div><div class="card">';
                echo '<h2 class="step-title"><span class="step-number">4</span> Location Search Test</h2>';
                echo '<p style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 20px;">Searching for locations matching "London"...</p>';

                $locations = $service->locationSearch('London');

                if (isset($locations['error']) && $locations['error']) {
                    echo '<div class="status-badge status-error">✕ Location Search Failed</div>';
                    echo '<pre>' . json_encode($locations['details'] ?? $locations, JSON_PRETTY_PRINT) . '</pre>';
                } else {
                    $count = count($locations['data'] ?? []);
                    echo '<div class="status-badge status-success">✓ Location Data Received</div>';
                    echo '<p style="margin-top: 15px;">Found <strong>' . $count . '</strong> locations for "London".</p>';
                    echo '<h3>Sample Results:</h3>';
                    echo '<pre>' . json_encode(array_slice($locations['data'], 0, 2), JSON_PRETTY_PRINT) . '</pre>';
                }
                
                // --- PROMINENT AMADEUS SUPPORT DATA ---
                $lastReq = $service->lastRequest;
                if (!empty($lastReq)) {
                    echo '</div><div class="card" style="border: 2px solid var(--primary); background: rgba(79, 70, 229, 0.05);">';
                    echo '<h2 class="step-title" style="color: var(--primary);">📋 Data for Amadeus Support</h2>';
                    echo '<p style="font-size: 0.875rem;">Copy these details and send them to the Amadeus investigation team:</p>';
                    
                    echo '<div class="copy-box" onclick="copyToClipboard(\'support_data\')">';
                    echo '<pre id="support_data" style="margin:0; border:none; background:transparent;">';
                    echo "Timestamp: " . ($lastReq['timestamp'] ?? 'N/A') . "\n";
                    echo "Ama-Client-Ref: " . ($lastReq['client_ref'] ?? 'N/A') . "\n";
                    echo "Endpoint: " . ($lastReq['endpoint'] ?? 'N/A') . "\n";
                    echo "HTTP Method: " . ($lastReq['method'] ?? 'N/A');
                    echo '</pre>';
                    echo '<small style="position:absolute; bottom:5px; right:10px; color:var(--primary);">Click to Copy</small>';
                    echo '</div>';
                    echo '</div>';
                }

            } else {
                echo '<div class="status-badge status-error">✕ Authentication Failed</div>';
                echo '<p style="color: var(--error); margin-top: 15px;">Failed to obtain access token. Please verify your <strong>AMADEUS_API_SECRET</strong> in the .env file.</p>';
                echo '<p style="font-size: 0.875rem; color: #94a3b8;">Common causes: Invalid client secret or API key, or your keys are for the "Production" environment while the script is using "Test".</p>';
            }
            echo '</div>';

        } catch (\Exception $e) {
            echo '<div class="card" style="border-color: var(--error);">';
            echo '<h2 style="color: var(--error);">System Error</h2>';
            echo '<p>' . $e->getMessage() . '</p>';
            echo '<pre>' . $e->getTraceAsString() . '</pre>';
            echo '</div>';
        }
        ?>

        <footer style="text-align: center; margin-top: 40px; color: #64748b; font-size: 0.875rem;">
            &copy; <?php echo date('Y'); ?> TripZant Development Tools. All rights reserved.
        </footer>
    </div>
</body>
</html>
