<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', "My Dashboard | Trip Zant")</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
        :root {
            --user-primary: #0b3d61;
            --user-secondary: #f97316;
            --user-bg: #f8fafc;
            --user-card-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--user-bg);
            color: #1e293b;
            overflow-x: hidden;
        }

        .dashboard-wrapper { display: flex; min-height: 100vh; }

        /* Sidebar */
        .dashboard-sidebar {
            width: 280px;
            background: #fff;
            border-right: 1px solid #e2e8f0;
            position: fixed;
            height: 100vh;
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px;
            text-align: center;
            border-bottom: 1px solid #f1f5f9;
        }

        .sidebar-nav { padding: 20px; }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 12px 20px;
            border-radius: 12px;
            color: #64748b;
            text-decoration: none;
            font-weight: 700;
            margin-bottom: 5px;
            transition: all 0.2s;
        }

        .sidebar-link:hover, .sidebar-link.active {
            background: rgba(11, 61, 97, 0.05);
            color: var(--user-primary);
        }
        
        .sidebar-link i { font-size: 18px; width: 24px; text-align: center; }

        /* Content */
        .dashboard-main {
            flex-grow: 1;
            margin-left: 280px;
            padding: 40px;
            transition: all 0.3s ease;
        }

        .user-top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .btn-website {
            background: rgba(11, 61, 97, 0.1);
            color: var(--user-primary);
            border-radius: 30px;
            padding: 10px 25px;
            font-weight: 800;
            font-size: 13px;
            border: none;
            text-decoration: none;
            transition: all 0.2s;
        }
        .btn-website:hover {
            background: var(--user-primary);
            color: #fff;
        }

        .dashboard-card {
            background: #fff;
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--user-card-shadow);
            border: 1px solid rgba(0,0,0,0.02);
            height: 100%;
        }

        .stat-badge {
            width: 50px;
            height: 50px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-bottom: 20px;
        }

        @media (max-width: 991px) {
            .dashboard-sidebar { left: -280px; }
            .dashboard-sidebar.active { left: 0; }
            .dashboard-main { margin-left: 0; padding: 25px; }
        }
    </style>
</head>
<body>
    <div class="dashboard-wrapper">
        <!-- Sidebar -->
        <aside class="dashboard-sidebar" id="dashboardSidebar">
            <div class="sidebar-header" style="padding: 24px 20px;">
                <img src="/img/logo.svg" style="width: 100%; height: auto; max-height: 50px; object-fit: contain;" alt="Trip Zant">
            </div>
            <div class="sidebar-nav">
                @if(request()->is('user-cargo*') || request()->is('cargo-agent*') || request()->is('cargo-hub*'))
                    <!-- Cargo Specific Sidebar (Module 1-6) -->
                    <a href="{{ route('cargo.dashboard.index') }}" class="sidebar-link {{ request()->routeIs('cargo.dashboard.index') && !request()->has('tab') ? 'active' : '' }}">
                        <i class="fas fa-th-large text-primary"></i> Cargo Home
                    </a>
                    <a href="{{ route('cargo.dashboard.index') }}?tab=all" class="sidebar-link {{ request()->query('tab') === 'all' ? 'active' : '' }}">
                        <i class="fas fa-boxes text-secondary"></i> My Shipments
                    </a>
                    <a href="{{ route('cargo.dashboard.book') }}" class="sidebar-link {{ request()->routeIs('cargo.dashboard.book') ? 'active' : '' }}">
                        <i class="fas fa-plus-circle text-success"></i> Book New Parcel
                    </a>
                    <a href="{{ route('cargo.dashboard.index') }}?tab=tracking" class="sidebar-link {{ request()->query('tab') === 'tracking' ? 'active' : '' }}">
                        <i class="fas fa-map-marked-alt text-info"></i> Tracking
                    </a>
                    <a href="{{ route('cargo.dashboard.index') }}?tab=invoices" class="sidebar-link {{ request()->query('tab') === 'invoices' ? 'active' : '' }}">
                        <i class="fas fa-file-invoice-dollar text-warning"></i> Invoice
                    </a>
                    <a href="{{ route('coming-soon') }}" class="sidebar-link">
                        <i class="fas fa-headset text-danger"></i> Support
                    </a>
                    <div class="mt-4 px-3 x-small fw-800 text-muted text-uppercase ls-1 mb-2">Account</div>
                    <a href="{{ route('dashboard.profile') }}" class="sidebar-link {{ request()->is('dashboard/profile') ? 'active' : '' }}">
                        <i class="fas fa-user-cog"></i> Profile Settings
                    </a>
                @else
                    <!-- Main Travel Sidebar -->
                    <a href="{{ route('dashboard.profile') }}" class="sidebar-link {{ request()->is('dashboard/profile') ? 'active' : '' }}">
                        <i class="fas fa-user-circle"></i> My Profile
                    </a>
                    <a href="{{ route('dashboard.bookings') }}" class="sidebar-link {{ request()->is('dashboard/bookings') ? 'active' : '' }}">
                        <i class="fas fa-suitcase"></i> My Bookings
                    </a>
                    <a href="{{ route('dashboard.wallet') }}" class="sidebar-link {{ request()->is('dashboard/wallet') ? 'active' : '' }}">
                        <i class="fas fa-wallet text-warning"></i> Tripzant Wallet
                    </a>
                    <a href="{{ route('dashboard.price-alerts') }}" class="sidebar-link {{ request()->is('dashboard/price-alerts') ? 'active' : '' }}">
                        <i class="fas fa-bell text-warning"></i> Price Alerts
                    </a>

                    <a href="{{ route('dashboard.wishlist') }}" class="sidebar-link {{ request()->is('dashboard/wishlist') ? 'active' : '' }}">
                        <i class="fas fa-heart"></i> Wishlist
                    </a>
                    <a href="{{ route('dashboard.searches') }}" class="sidebar-link {{ request()->is('dashboard/searches') ? 'active' : '' }}">
                        <i class="fas fa-search"></i> Saved Searches
                    </a>
                    <a href="{{ route('dashboard.notifications') }}" class="sidebar-link {{ request()->is('dashboard/notifications') ? 'active' : '' }}">
                        <i class="fas fa-bell"></i> Notifications
                    </a>
                    <a href="{{ route('dashboard.settings') }}" class="sidebar-link {{ request()->is('dashboard/settings') ? 'active' : '' }}">
                        <i class="fas fa-cog"></i> Settings
                    </a>
                @endif

                <hr class="my-4 opacity-10">
                <a href="/logout" class="sidebar-link text-danger">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
        </aside>

        <!-- Main -->
        <main class="dashboard-main">
            <div class="user-top-bar">
                <div class="d-flex align-items-center gap-3">
                    <button class="btn d-lg-none border-0 p-0" onclick="toggleSidebar()">
                        <i class="fas fa-bars fs-4"></i>
                    </button>
                    <h5 class="fw-900 text-navy mb-0">Member Dashboard</h5>
                </div>
                <a href="/" class="btn-website"><i class="fas fa-globe me-2"></i> Go to Website</a>
            </div>

            @yield('dashboard_content')
        </main>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById('dashboardSidebar').classList.toggle('active');
        }
    </script>
    @stack('scripts')
</body>
</html>
