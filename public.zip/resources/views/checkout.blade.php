@extends('layouts.app')

@section('title', 'Secure Checkout | Trip\'Stay')

@section('styles')
<style>
    :root {
        --checkout-bg: #f4f7fa;
        --navy: #0b3d61;
        --orange: #f97316;
        --green: #22c55e;
    }

    body { background-color: var(--checkout-bg); }

    .checkout-header-steps {
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
        position: sticky;
        top: 70px;
        z-index: 100;
        padding: 15px 0;
    }

    .step-item {
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        color: #94a3b8;
    }

    .step-item.active { color: var(--navy); }
    .step-item.completed { color: var(--green); }

    .step-number {
        width: 24px;
        height: 24px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #e2e8f0;
        color: #64748b;
        font-size: 11px;
    }

    .step-item.active .step-number { background: var(--navy); color: #fff; }
    .step-item.completed .step-number { background: var(--green); color: #fff; }

    .price-lock-banner {
        background: var(--navy);
        color: #fff;
        padding: 8px 20px;
        border-radius: 50px;
        font-size: 13px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-weight: 700;
    }

    .checkout-card {
        background: #fff;
        border-radius: 20px;
        padding: 30px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        margin-bottom: 25px;
        border: 1px solid rgba(0,0,0,0.02);
    }

    .form-label-premium {
        font-size: 10px;
        font-weight: 800;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
        display: block;
    }

    .custom-input {
        border: 1.5px solid #e2e8f0;
        border-radius: 12px;
        padding: 12px 16px;
        font-weight: 700;
        color: var(--navy);
        font-size: 14px;
        transition: all 0.2s;
    }

    .custom-input:focus {
        border-color: var(--navy);
        box-shadow: 0 0 0 4px rgba(11, 61, 97, 0.05);
        outline: none;
    }

    .payment-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 15px;
        margin-bottom: 25px;
    }

    .pay-card {
        border: 1.5px solid #e2e8f0;
        border-radius: 15px;
        padding: 20px;
        cursor: pointer;
        transition: all 0.2s;
        position: relative;
    }

    .pay-card.active {
        border-color: var(--navy);
        background: rgba(11, 61, 97, 0.02);
    }

    .pay-card .check-icon {
        position: absolute;
        top: 10px;
        right: 10px;
        color: var(--navy);
        display: none;
    }

    .pay-card.active .check-icon { display: block; }

    .fare-summary-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
        font-size: 14px;
        font-weight: 600;
        color: #64748b;
    }

    .total-row {
        border-top: 1.5px dashed #e2e8f0;
        margin-top: 20px;
        padding-top: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .btn-confirm {
        background: var(--navy);
        color: #fff;
        border: none;
        border-radius: 15px;
        padding: 18px;
        font-weight: 800;
        width: 100%;
        margin-top: 20px;
        transition: all 0.3s;
    }

    .btn-confirm:hover {
        background: #001f3f;
        transform: translateY(-2px);
        box-shadow: 0 10px 20px rgba(11, 61, 97, 0.2);
    }
    .bg-primary-light { background: rgba(11, 61, 97, 0.05); }
    .border-dashed { border-style: dashed !important; }

    /* Passport Expiry Warning */
    .passport-warning {
        display: none;
        align-items: flex-start;
        gap: 10px;
        background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
        border: 1.5px solid #fb923c;
        border-radius: 12px;
        padding: 12px 16px;
        margin-top: 8px;
        animation: slideInWarning 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }
    .passport-warning.show { display: flex; }
    @keyframes slideInWarning {
        from { opacity: 0; transform: translateY(-8px) scale(0.97); }
        to   { opacity: 1; transform: translateY(0)  scale(1); }
    }
    .passport-warning-icon {
        width: 32px; height: 32px; min-width: 32px;
        background: #fb923c;
        border-radius: 8px;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-size: 15px;
    }
    .passport-warning-title {
        font-size: 12px; font-weight: 900;
        color: #9a3412; text-transform: uppercase; letter-spacing: 0.5px;
        margin-bottom: 2px;
    }
    .passport-warning-body {
        font-size: 12px; font-weight: 600; color: #c2410c; line-height: 1.5;
    }
    .passport-expiry-input.is-invalid-passport {
        border-color: #fb923c !important;
        box-shadow: 0 0 0 4px rgba(251, 146, 60, 0.12) !important;
    }

    /* FFN Styling */
    .ffn-toggle:checked {
        background-color: #f97316;
        border-color: #f97316;
    }
    .ffn-fields {
        animation: fadeInDown 0.3s ease;
    }
    @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
@endsection

@section('content')
<div class="checkout-header-steps">
    <div class="container d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-4">
            <div class="step-item completed">
                <div class="step-number"><i class="fas fa-check"></i></div>
                <span>Search</span>
            </div>
            <div style="width:30px; height:2px; background:#e2e8f0;"></div>
            <div class="step-item completed">
                <div class="step-number"><i class="fas fa-check"></i></div>
                <span>Select</span>
            </div>
            <div style="width:30px; height:2px; background:#e2e8f0;"></div>
            <div class="step-item active">
                <div class="step-number">3</div>
                <span>Payment</span>
            </div>
        </div>
        <div class="price-lock-banner">
            <i class="fas fa-bolt-lightning text-warning"></i>
            <span>PRICE LOCKED FOR <span id="timer" class="font-monospace ms-2">09:59</span></span>
        </div>
    </div>
</div>

<div class="container py-5">
    <div class="row g-4">
        <!-- Left Column -->
        <div class="col-lg-8">
            @if(auth()->check() && (auth()->user()->name == 'New User' || !auth()->user()->phone))
                <!-- Mandatory Profile Update -->
                <div id="compulsory-profile-section" class="card border-0 shadow-sm mb-4 reveal p-4" style="border-radius:24px; border: 2.5px solid #0076f7 !important; background: #f0f9ff;">
                    <h5 class="fw-900 text-navy mb-1 d-flex align-items-center gap-3">
                         <span class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width:40px; height:40px; font-size: 16px;"><i class="fas fa-user-edit"></i></span>
                         Completing Your Secure Profile
                         <span class="badge bg-danger rounded-pill x-small px-3 py-2" style="font-size: 10px; letter-spacing: 1px;">ACTION REQUIRED</span>
                    </h5>
                    <p class="text-muted small fw-bold mb-4 ps-5">We need your official details to issue your booking tickets and send SMS updates.</p>
                    
                    <div class="row g-3 ps-md-5">
                        <div class="col-md-6">
                            <label class="form-label small fw-900 text-navy mb-2" style="font-size: 11px; letter-spacing: 0.5px;">YOUR FULL NAME (AS PER ID)</label>
                            <div class="input-group border rounded-pill overflow-hidden bg-white shadow-sm">
                                <span class="input-group-text bg-white border-0 px-3"><i class="fas fa-user opacity-50"></i></span>
                                <input type="text" id="profile_name_update" class="form-control border-0 py-2 px-1 fw-bold" value="{{ auth()->user()->name != 'New User' ? auth()->user()->name : '' }}" placeholder="e.g. Rahul Sharma" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-900 text-navy mb-2" style="font-size: 11px; letter-spacing: 0.5px;">VERIFIED CONTACT NUMBER</label>
                            <div class="input-group border rounded-pill overflow-hidden bg-white shadow-sm">
                                <span class="input-group-text bg-white border-0 px-3"><i class="fas fa-phone opacity-50"></i></span>
                                <input type="text" id="profile_phone_update" class="form-control border-0 py-2 px-1 fw-bold" value="{{ auth()->user()->phone }}" placeholder="10-Digit Mobile Number" required>
                            </div>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Travelers Section -->
            <div id="booking-main-form">
            <!-- Multi-Class Inventory Summary (Sticky Top) -->
            <div id="classInventorySummary" class="checkout-card mb-4 bg-primary text-white shadow-lg sticky-top" style="display: none; border: none; background: linear-gradient(135deg, #0b3d61 0%, #1e293b 100%); top: 150px; z-index: 10;">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="fw-900 mb-1"><i class="fas fa-couch me-2 text-warning"></i> Multi-Class Inventory</h6>
                        <p class="mb-0 opacity-75 fw-bold" style="font-size: 10px;">ALLOCATE YOUR PASSENGERS TO THE PURCHASED SEATS</p>
                    </div>
                    <div class="d-flex gap-2" id="inventoryPills">
                        <!-- Pills will be injected here: e.g. <span class="badge bg-success">4 BUSINESS LEFT</span> -->
                    </div>
                </div>
            </div>

            <!-- Bulk Upload Premium Card -->
            <div class="checkout-card mb-4" style="background: linear-gradient(135deg, #fff 0%, #f8fafc 100%); border: 2px dashed #cbd5e1; border-style: dashed !important; position: relative; overflow: hidden;">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h6 class="fw-900 text-navy mb-1"><i class="fas fa-file-excel me-2 text-success"></i> Bulk Passenger Upload</h6>
                        <p class="text-muted xx-small fw-bold mb-0" style="font-size: 10px;">UPLOAD EXCEL / CSV / PDF MANIFEST TO AUTO-FILL ALL DETAILS</p>
                    </div>
                    <a href="javascript:void(0)" onclick="downloadSampleCSV()" class="text-primary fw-800" style="font-size: 10px; text-decoration: underline;">DOWNLOAD TEMPLATE</a>
                </div>
                
                <div class="upload-zone p-4 bg-white rounded-3 border d-flex flex-column align-items-center justify-content-center cursor-pointer transition hvr-light" onclick="document.getElementById('bulkUploadInput').click()">
                    <i class="fas fa-cloud-upload-alt fs-2 text-primary mb-3"></i>
                    <div class="fw-800 text-navy mb-1">Click or drag & drop to upload traveler manifest</div>
                    <div class="text-muted x-small fw-bold">Supported formats: .xlsx, .csv, .pdf (Max 5MB)</div>
                    <input type="file" id="bulkUploadInput" class="d-none" accept=".csv, .xlsx, .pdf" onchange="handleBulkUpload(this)">
                </div>

                <!-- Progress Mock (Hidden by default) -->
                <div id="uploadProgress" class="d-none mt-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-navy fw-800" style="font-size: 11px;">Parsing Passengers...</span>
                        <span id="progressPercent" class="text-primary fw-900" style="font-size: 11px;">0%</span>
                    </div>
                    <div class="progress" style="height: 6px; border-radius: 10px;">
                        <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-primary" style="width: 0%"></div>
                    </div>
                </div>
            </div>

            <div id="travelersContainer">
                <!-- Single Traveler Block -->
                <div class="checkout-card traveler-block shadow-sm mb-4" id="traveler-1">
                    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
                        <div class="d-flex align-items-center gap-3">
                            <h5 class="fw-900 text-navy mb-0">Traveler #1 <span class="badge bg-primary-light text-navy fw-800 x-small ms-2 primary-tag">PRIMARY</span></h5>
                            <div class="class-selector-area d-flex align-items-center gap-2">
                                <span class="text-muted fw-bold" style="font-size: 10px;">CABIN:</span>
                                <select class="form-select border-navy text-navy fw-800 cabin-class-dropdown" style="font-size: 11px; padding: 4px 12px; border-radius: 50px; width: auto;" onchange="validateAllocation(this)">
                                    <option value="Y">ECONOMY (Y)</option>
                                    <option value="J">BUSINESS (J)</option>
                                    <option value="S">SAVER (B)</option>
                                </select>
                            </div>
                        </div>
                        <button class="btn btn-sm btn-outline-danger border-0 d-none remove-traveler" onclick="this.closest('.traveler-block').remove(); reorderTravelers();"><i class="fas fa-trash-alt"></i></button>
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-2">
                            <label class="form-label-premium">Title</label>
                            <select class="form-select custom-input"><option>Mr</option><option>Mrs</option><option>Ms</option></select>
                        </div>
                        <div class="col-md-5">
                            <label class="form-label-premium">First Name</label>
                            <input type="text" class="form-control custom-input" placeholder="e.g. Rahul" value="">
                        </div>
                        <div class="col-md-5">
                            <label class="form-label-premium">Last Name</label>
                            <input type="text" class="form-control custom-input" placeholder="e.g. Sharma" value="">
                        </div>
                        
                        <div class="col-md-4">
                            <label class="form-label-premium">Date of Birth</label>
                            <input type="date" class="form-control custom-input">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-premium">Gender</label>
                            <select class="form-select custom-input">
                                <option disabled selected>Select</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Non-binary</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label-premium">Mobile Number</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0 custom-input px-2" style="border-radius: 12px 0 0 12px; font-size:12px;">+91</span>
                                <input type="tel" class="form-control custom-input border-start-0" value="" style="border-radius: 0 12px 12px 0;" placeholder="Mobile Number">
                            </div>
                        </div>

                        @php
                            $isInternational = false;
                            if($type === 'flight' && isset($item)) {
                                // Default to domestic if we can't tell, or add logic
                                // Let's check for currency or price or just set false for now to satisfy domestic use-case
                                $isInternational = false; // By default assume domestic unless flagged
                            }
                        @endphp

                        {{-- Only show ID section for Flights and eSIM --}}
                        @if($type === 'flight' || $type === 'esim')
                            <div class="col-12 mt-4 pt-3 border-top border-light">
                                <h6 class="fw-800 text-navy small mb-3">
                                    <i class="fas fa-id-card me-2 text-primary"></i> 
                                    @if($type === 'esim' || $isInternational)
                                        Mandatory Travel Documents (Passport)
                                    @else
                                        Identification Proof (Domestic)
                                    @endif
                                </h6>
                            </div>

                            @if($type === 'esim' || $isInternational)
                                <div class="col-md-6">
                                    <label class="form-label-premium">Passport Number</label>
                                    <input type="text" class="form-control custom-input" placeholder="Enter passport number">
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label-premium">Passport Expiry Date</label>
                                    <input type="date" class="form-control custom-input passport-expiry-input" onchange="validatePassportExpiry(this)">
                                </div>
                            @else
                                <div class="col-md-6">
                                    <label class="form-label-premium">ID Type (Aadhar/Voter/DL)</label>
                                    <select class="form-select custom-input">
                                        <option>Aadhar Card</option>
                                        <option>Voter ID</option>
                                        <option>Driving License</option>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label-premium">ID Number</label>
                                    <input type="text" class="form-control custom-input" placeholder="e.g. 1234 5678 9012">
                                </div>
                            @endif

                            <div class="col-12 mt-3 mb-4">
                                <label class="form-label-premium">Full Residential Address</label>
                                <textarea class="form-control custom-input" rows="2" placeholder="Street, House No, City, Pincode"></textarea>
                            </div>
                        @else
                            {{-- For Homestays, Hotels etc - No mandatory ID at checkout - faster booking! --}}
                            <div class="col-12 mt-4 pt-3 border-top border-light opacity-50">
                                <p class="small fw-bold text-muted mb-0"><i class="fas fa-info-circle me-1"></i> No ID required at booking. Please carry a valid Government ID for check-in.</p>
                            </div>
                        @endif

                        <!-- Frequent Flyer Details -->
                        <div class="col-12 mt-4 pt-3 border-top border-light">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="fw-800 text-navy small mb-0"><i class="fas fa-award me-2 text-warning"></i> Frequent Flyer Details</h6>
                                <div class="form-check form-switch">
                                    <input class="form-check-input ffn-toggle" type="checkbox" onchange="toggleFFN(this)">
                                    <label class="form-check-label small fw-700 text-muted" style="font-size: 10px; cursor: pointer;">ADD FFN</label>
                                </div>
                            </div>
                            <div class="row g-3 ffn-fields" style="display: none;">
                                <div class="col-md-6">
                                    <label class="form-label-premium">Loyalty Program</label>
                                    <select class="form-select custom-input ffn-airline">
                                        <option value="" disabled selected>Select Program</option>
                                        <optgroup label="Popular Programs">
                                            <option value="6E">IndiGo - 6E Rewards</option>
                                            <option value="EK">Emirates - Skywards</option>
                                            <option value="AI">Air India - Flying Returns</option>
                                            <option value="EY">Etihad - Guest</option>
                                            <option value="QR">Qatar Airways - Privilege Club</option>
                                        </optgroup>
                                        <optgroup label="Other Partners">
                                            <option value="UK">Vistara - Club Vistara</option>
                                            <option value="SG">SpiceJet - SpiceClub</option>
                                        </optgroup>
                                    </select>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label-premium">Member Number</label>
                                    <input type="text" class="form-control custom-input ffn-number" placeholder="e.g. EK123456789">
                                    <div class="text-muted mt-1" style="font-size: 9px; font-weight: 700;">Earn miles for this booking</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add Traveler Button -->
            <button class="btn btn-outline-navy w-100 rounded-pill py-3 mb-4 fw-900 border-dashed" id="addTravelerBtn" style="border: 2px dashed #cbd5e1; background: #fff;">
                <i class="fas fa-plus-circle me-2"></i> ADD ANOTHER TRAVELER
            </button>

            <!-- Booking Summary Card -->
            <div class="checkout-card">
                <div class="d-flex gap-4 align-items-center">
                    <img id="bookingItemImg" src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=200" class="rounded-4" style="width: 120px; height: 100px; object-fit: cover;">
                    <div>
                        <h6 id="bookingItemTitle" class="fw-900 text-navy mb-1">Taj Exotica Resort & Spa</h6>
                        <p id="bookingItemSubtitle" class="text-muted small fw-bold mb-3"><i class="fas fa-map-marker-alt me-1"></i> Benaulim Beach, South Goa</p>
                        <div id="bookingItemDetails" class="d-flex gap-4">
                            <div class="small fw-bold text-navy">Check-in: <span class="text-muted">12 Nov' 25</span></div>
                            <div class="small fw-bold text-navy">Length: <span class="text-muted">3 Nights</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GST Billing Section -->
            <div class="checkout-card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-900 text-navy mb-0"><i class="fas fa-file-invoice me-2 text-primary"></i> GST Invoicing (Optional)</h5>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="gstToggle" onchange="toggleGST(this)">
                        <label class="form-check-label small fw-bold text-muted">ADD GST</label>
                    </div>
                </div>
                <div id="gstFields" class="row g-3 d-none">
                    <div class="col-md-6">
                        <label class="form-label-premium">GST Number</label>
                        <input type="text" class="form-control custom-input" placeholder="e.g. 07AAAAA0000A1Z5">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label-premium">Company Name</label>
                        <input type="text" class="form-control custom-input" placeholder="Registered Company Name">
                    </div>
                    <div class="col-12">
                        <label class="form-label-premium">Company Address</label>
                        <input type="text" class="form-control custom-input" placeholder="Full Registered Address">
                    </div>
                </div>
            </div>

            <!-- Payment -->
            <div class="checkout-card">
                <h5 class="fw-900 text-navy mb-4">Select Payment Method</h5>

                <!-- Slice Pay Banner (Checkout Page) -->
                <div class="alert mt-0 mb-4 p-3 rounded-4 d-flex align-items-center justify-content-between border-0 shadow-sm" style="background-color: #f7fbff; border-radius: 12px; cursor: pointer; border: 1px solid rgba(86,168,255,0.2) !important;">
                    <div>
                        <div class="fw-bold mb-1" style="font-size: 15px; color: #1a202c; letter-spacing: -0.2px;">
                            <span class="badge" style="background-color: #e2e8f0; color: #1e293b; padding: 4px 8px; font-weight: 800; font-size: 13px; margin-right: 6px;">Slice Pay</span>
                            <span style="font-size: 15px; font-weight: 700;">Pay in 12 instalments</span>
                        </div>
                        <div class="text-muted" style="font-size: 13px; font-weight: 600;">Lock in today's price. No fees.</div>
                    </div>
                    <div class="ms-auto flex-shrink-0">
                         <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Slice_logo.svg/1200px-Slice_logo.svg.png" alt="Slice Logo" style="height: 30px; object-fit: contain; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));">
                    </div>
                </div>

                <div class="payment-grid">
                    <div class="pay-card active">
                        <i class="fas fa-check-circle check-icon"></i>
                        <i class="fas fa-credit-card fs-4 mb-2 text-primary"></i>
                        <div class="fw-800 small text-navy">Card</div>
                        <div class="xx-small text-muted fw-bold" style="font-size: 10px;">Visa, Master</div>
                    </div>
                    <div class="pay-card">
                        <i class="fas fa-mobile-button fs-4 mb-2 text-success"></i>
                        <div class="fw-800 small text-navy">UPI</div>
                        <div class="xx-small text-muted fw-bold" style="font-size: 10px;">GPay, PhonePe</div>
                    </div>
                    <div class="pay-card">
                        <i class="fas fa-university fs-4 mb-2 text-warning"></i>
                        <div class="fw-800 small text-navy">Net Banking</div>
                        <div class="xx-small text-muted fw-bold" style="font-size: 10px;">All Banks</div>
                    </div>
                    <!-- Tripzant Wallet -->
                    <div class="pay-card wallet-option" style="background: rgba(var(--primary-rgb), 0.03); border: 2px solid rgba(var(--primary-rgb), 0.2);">
                        <div class="badge bg-warning text-dark position-absolute top-0 end-0 m-1 x-small fw-900 rounded-pill px-2" style="font-size:8px;">RECOMMENDED</div>
                        <i class="fas fa-wallet fs-4 mb-2 text-primary"></i>
                        <div class="fw-900 small text-navy">Tripzant Wallet</div>
                        <div class="xx-small text-primary fw-900 mt-1" style="font-size: 11px;">BAL: ₹12,450</div>
                    </div>
                </div>

                <div class="p-4 bg-light rounded-4">
                    <div class="row g-3">
                        <div class="col-12"><input type="text" class="form-control custom-input" placeholder="Card Number" value="4111 2222 3456 4023"></div>
                        <div class="col-md-6"><input type="text" class="form-control custom-input" placeholder="MM/YY"></div>
                        <div class="col-md-6"><input type="password" class="form-control custom-input" placeholder="CVV"></div>
                        <div class="col-12"><input type="text" class="form-control custom-input" placeholder="Cardholder Name"></div>
                    </div>
                </div>
            </div>
            </div>
        </div>

        <!-- Price Summary Column -->
        <div class="col-lg-4">
            <div class="checkout-card sticky-top" style="top: 150px;">
                <h5 class="fw-900 text-navy mb-4">Price Summary</h5>
                <div class="fare-summary-row border-bottom pb-2 mb-2">
                    <span class="text-muted fw-bold small">Base Fare</span>
                    <span id="summaryBaseFare" class="text-navy fw-800">₹0</span>
                </div>
                <div class="fare-summary-row border-bottom pb-2 mb-2">
                    <span class="text-muted fw-bold small">Taxes & Service Fee</span>
                    <span id="summaryTaxes" class="text-navy fw-800">₹0</span>
                </div>
                <div id="discountRow" class="fare-summary-row text-success border-bottom pb-2 mb-2 d-none">
                    <span class="fw-bold small">Promotional Discount</span>
                    <span id="summaryDiscount" class="fw-800">-₹0</span>
                </div>

                <div class="total-row mt-4 p-3 bg-primary-light rounded-4">
                    <div>
                        <div class="form-label-premium mb-0 fw-900 text-primary" style="font-size: 10px;">TOTAL AMOUNT PAYABLE</div>
                        <div id="summaryTotal" class="display-6 fw-900 text-navy" style="font-size: 1.8rem;">₹0</div>
                    </div>
                </div>

                <button onclick="confirmBooking()" class="btn-confirm btn btn-primary w-100 py-3 rounded-pill fw-900 shadow-lg mt-4" style="font-size: 15px;">
                    CONFIRM BOOKING <i class="fas fa-arrow-right ms-2"></i>
                </button>
                
                <div class="text-center mt-3">
                    <span class="text-muted fw-bold" style="font-size: 11px;"><i class="fas fa-lock me-1"></i> Safe & Secure Checkout</span>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
    const isLoggedIn = {{ Auth::check() ? 'true' : 'false' }};

    // Initialize from LocalStorage or Server Data
    document.addEventListener('DOMContentLoaded', function() {
        const type = "{{ $type }}";
        @if(isset($item))
        const itemData = @json($item);
        if (itemData) {
            console.log("Loading checkout data for", type, itemData);
            
            // 1. Resolve Price
            let baseFare = 0;
            if (type === 'flight') baseFare = itemData.price;
            else if (type === 'homestay') baseFare = itemData.price_per_night;
            else if (type === 'esim') baseFare = itemData.price;
            else if (type === 'tour') baseFare = itemData.price;
            else if (type === 'insurance') baseFare = itemData.price;

            const taxes = Math.round(baseFare * 0.18);
            const total = baseFare + taxes; 

            document.getElementById('summaryBaseFare').innerText = '₹' + baseFare.toLocaleString();
            document.getElementById('summaryTaxes').innerText = '₹' + taxes.toLocaleString();
            document.getElementById('summaryTotal').innerText = '₹' + total.toLocaleString();

            // 2. Resolve Itinerary Info
            if (type === 'flight') {
                document.getElementById('bookingItemTitle').innerText = itemData.airline;
                document.getElementById('bookingItemSubtitle').innerHTML = `<i class="fas fa-plane me-1"></i> ${itemData.dep_city} → ${itemData.arr_city} (${itemData.flight_no})`;
                document.getElementById('bookingItemDetails').innerHTML = `
                    <div class="small fw-bold text-navy">Departure: <span class="text-muted">${itemData.dep_time}</span></div>
                    <div class="small fw-bold text-navy">Arrival: <span class="text-muted">${itemData.arr_time}</span></div>
                `;
                if (itemData.airline_logo) document.getElementById('bookingItemImg').src = itemData.airline_logo;
            } else {
                document.getElementById('bookingItemTitle').innerText = itemData.title || itemData.name;
                document.getElementById('bookingItemSubtitle').innerHTML = `<i class="fas fa-map-marker-alt me-1 text-primary"></i> ${itemData.city || itemData.region || 'Service'}`;
                document.getElementById('bookingItemDetails').innerHTML = `
                    <div class="small fw-bold text-navy">Type: <span class="text-muted text-uppercase">${type}</span></div>
                    <div class="small fw-bold text-navy">Status: <span class="text-muted">Instant Confirmation</span></div>
                `;
                const img = itemData.image_url || itemData.image;
                if (img) document.getElementById('bookingItemImg').src = img;
                
                // Change Button Text for non-flights
                document.querySelector('.btn-confirm').innerHTML = 'CONFIRM BOOKING <i class="fas fa-arrow-right ms-2"></i>';
            }
        }
        @endif
        
        initInventory();
    });

    window.confirmBooking = function() {
        console.log("Confirming booking. Logged in:", isLoggedIn);
        
        if (!isLoggedIn) {
            openAuthModal();
            return;
        }

        const btn = document.querySelector('.btn-confirm');
        const originalText = btn.innerHTML;

        // Collect Mandatory Profile Update if fields exist
        const profileName = document.getElementById('profile_name_update');
        const profilePhone = document.getElementById('profile_phone_update');
        let profileUpdate = null;

        if (profileName && profilePhone) {
            if (!profileName.value.trim() || !profilePhone.value.trim()) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Profile Incomplete',
                    text: 'Please enter your Full Name and Mobile Number to proceed.',
                    confirmButtonColor: '#0076f7'
                });
                return;
            }
            profileUpdate = {
                name: profileName.value.trim(),
                phone: profilePhone.value.trim()
            };
        }
        
        try {
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i> PROCESSING...';
            btn.classList.add('disabled');
            
            // Collect Traveler Data safely
            const travelers = [];
            const blocks = document.querySelectorAll('.traveler-block');
            
            if (blocks.length === 0) throw new Error("Please add at least one traveler.");

            blocks.forEach((block, idx) => {
                const fname = block.querySelector('input[placeholder*="Rahul"]')?.value || 
                              block.querySelector('input[name*="first_name"]')?.value;
                const lname = block.querySelector('input[placeholder*="Sharma"]')?.value ||
                              block.querySelector('input[name*="last_name"]')?.value;
                
                if (!fname || !lname) throw new Error(`Please enter full name for Traveler #${idx + 1}`);

                travelers.push({
                    first_name: fname,
                    last_name: lname,
                    dob: block.querySelector('input[type="date"]')?.value || '1995-01-01',
                    passport: block.querySelector('input[placeholder*="passport"]')?.value || '',
                    cabin: block.querySelector('.cabin-class-dropdown')?.value || 'Economy'
                });
            });

            const itemData = @json($item);
            const type = "{{ $type }}";
            
            if (!itemData) throw new Error("Session expired. Please search again.");

            let baseFare = 0;
            if (type === 'flight') baseFare = itemData.price;
            else if (type === 'homestay') baseFare = itemData.price_per_night;
            else baseFare = itemData.price || 0;

            const payload = {
                _token: "{{ csrf_token() }}",
                type: type,
                net_price: itemData.net_price || baseFare,
                selling_price: baseFare + (baseFare * 0.18),
                markup: itemData.markup_applied || 0,
                email: document.querySelector('#traveler-1 input[type="email"]')?.value || 
                       document.querySelector('input[type="email"]')?.value || 
                       "{{ Auth::user()->email ?? '' }}",
                phone: profileUpdate ? profileUpdate.phone : ("{{ Auth::user()->phone ?? '' }}"),
                travelers: travelers,
                item_id: itemData.id,
                profile_update: profileUpdate
            };

            fetch("{{ route('checkout.process') }}", {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': "{{ csrf_token() }}",
                    'Accept': 'application/json'
                },
                body: JSON.stringify(payload)
            })
            .then(r => r.json().catch(() => { throw new Error("Invalid server response. Please try again."); }))
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        title: 'Success!',
                        text: data.message,
                        icon: 'success',
                        timer: 3000,
                        showConfirmButton: false
                    }).then(() => {
                        window.location.href = data.redirect;
                    });
                } else {
                    throw new Error(data.message || "Booking failed. Please check your balance.");
                }
            })
            .catch(err => {
                console.error(err);
                Swal.fire('Booking Failed', err.message, 'error');
                btn.innerHTML = originalText;
                btn.classList.remove('disabled');
            });

        } catch (e) {
            console.error(e);
            Swal.fire('Action Required', e.message, 'warning');
            btn.innerHTML = originalText;
            btn.classList.remove('disabled');
        }
    }

    // GST Toggle
    window.toggleGST = function(el) {
        const fields = document.getElementById('gstFields');
        if(el.checked) fields.classList.remove('d-none');
        else fields.classList.add('d-none');
    }

    // Timer Logic
    let timeLeft = 600;
    const timerElem = document.getElementById('timer');
    setInterval(() => {
        if(timeLeft <= 0) return;
        timeLeft--;
        let m = Math.floor(timeLeft / 60);
        let s = timeLeft % 60;
        timerElem.innerText = `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    }, 1000);

    // Dynamic Traveler Logic
    const travelersContainer = document.getElementById('travelersContainer');
    let travelerCount = 1;
    let purchasedInventory = {}; // e.g. { 'J': 4, 'Y': 8 }

    // Initialize Inventory from LocalStorage
    function initInventory() {
        const cart = JSON.parse(localStorage.getItem('splitCart') || '[]');
        if (cart.length > 0) {
            document.getElementById('classInventorySummary').style.display = 'block';
            cart.forEach(item => {
                purchasedInventory[item.class] = (purchasedInventory[item.class] || 0) + parseInt(item.seats);
            });
            updateInventoryStatus();
        }
    }

    function updateInventoryStatus() {
        const summary = document.getElementById('inventoryPills');
        summary.innerHTML = '';
        
        // Count currently allocated
        const allocated = {};
        document.querySelectorAll('.cabin-class-dropdown').forEach(d => {
            allocated[d.value] = (allocated[d.value] || 0) + 1;
        });

        Object.keys(purchasedInventory).forEach(cls => {
            const total = purchasedInventory[cls];
            const used = allocated[cls] || 0;
            const left = total - used;
            const color = left < 0 ? 'bg-danger' : (left === 0 ? 'bg-success opacity-50' : 'bg-warning text-dark');
            const label = cls === 'J' ? 'BUSINESS' : (cls === 'Y' ? 'ECONOMY' : 'SAVER');
            
            summary.innerHTML += `
                <div class="badge ${color} px-3 py-2 rounded-pill d-flex flex-column align-items-center" style="min-width: 80px;">
                    <span style="font-size: 8px; font-weight: 900; opacity: 0.8;">${label}</span>
                    <span style="font-size: 11px; font-weight: 900;">${left} LEFT</span>
                </div>
            `;
        });
    }

    window.validateAllocation = function(select) {
        updateInventoryStatus();
        // Simple over-allocation check
        const allocated = {};
        document.querySelectorAll('.cabin-class-dropdown').forEach(d => {
            allocated[d.value] = (allocated[d.value] || 0) + 1;
        });
        
        Object.keys(allocated).forEach(cls => {
            if (allocated[cls] > (purchasedInventory[cls] || 0)) {
                Swal.fire({
                    title: 'Capacity Reached',
                    text: `You only purchased ${purchasedInventory[cls]} seats for this class.`,
                    icon: 'warning',
                    confirmButtonColor: 'var(--navy)'
                });
            }
        });
    }

    // 1. Define Helper First
    function addTravelerWithData(data) {
        console.log("Adding traveler:", data.first);
        const container = document.getElementById('travelersContainer');
        const blocks = document.querySelectorAll('.traveler-block');
        let targetBlock = null;

        // 1. Check if first block is empty, use it if so
        if (blocks.length === 1) {
            const fName = blocks[0].querySelector('input[placeholder*="Rahul"]')?.value || '';
            const lName = blocks[0].querySelector('input[placeholder*="Sharma"]')?.value || '';
            if (!fName && !lName) {
                targetBlock = blocks[0];
            }
        }

        // 2. Otherwise clone the first one
        if (!targetBlock) {
            const template = document.querySelector('.traveler-block');
            if (!template) return null;
            
            targetBlock = template.cloneNode(true);
            travelerCount++;
            targetBlock.id = `traveler-${travelerCount}`;
            
            // Clear all values in clone
            targetBlock.querySelectorAll('input').forEach(i => i.value = '');
            targetBlock.querySelectorAll('select').forEach(s => s.selectedIndex = 0);
            targetBlock.querySelectorAll('textarea').forEach(t => t.value = '');
            
            // Reset visibility states
            const warning = targetBlock.querySelector('.passport-warning');
            if (warning) warning.classList.remove('show');
            const ffnFields = targetBlock.querySelector('.ffn-fields');
            if (ffnFields) ffnFields.style.display = 'none';
            const ffnToggle = targetBlock.querySelector('.ffn-toggle');
            if (ffnToggle) ffnToggle.checked = false;

            // Remove primary badge if it's not the first anymore
            const badge = targetBlock.querySelector('.primary-tag');
            if (badge) badge.remove();

            // Setup Delete Button
            const delBtn = targetBlock.querySelector('.remove-traveler');
            if (delBtn) {
                delBtn.classList.remove('d-none');
                delBtn.onclick = function() {
                    targetBlock.remove();
                    reorderTravelers();
                    updateInventoryStatus();
                };
            }

            container.appendChild(targetBlock);
        }

        // 3. Populate Data
        try {
            // Cabin Class Logic
            const classSelect = targetBlock.querySelector('.cabin-class-dropdown');
            if (classSelect) {
                const currentAlloc = {};
                document.querySelectorAll('.cabin-class-dropdown').forEach(d => {
                    currentAlloc[d.value] = (currentAlloc[d.value] || 0) + 1;
                });
                
                // Find a class that has room
                for (const cls in purchasedInventory) {
                    if ((currentAlloc[cls] || 0) < purchasedInventory[cls]) {
                        classSelect.value = cls;
                        break;
                    }
                }
            }

            // Names & Main Info
            const textInputs = targetBlock.querySelectorAll('input[type="text"]');
            const dateInputs = targetBlock.querySelectorAll('input[type="date"]');
            const selects = targetBlock.querySelectorAll('select:not(.cabin-class-dropdown)');
            
            if (data.title && selects[0]) selects[0].value = data.title;
            if (data.first && textInputs[0]) textInputs[0].value = data.first;
            if (data.last && textInputs[1]) textInputs[1].value = data.last;
            if (data.gender && selects[1]) selects[1].value = data.gender;
            if (data.dob && dateInputs[0]) dateInputs[0].value = data.dob;
            
            const mobileInput = targetBlock.querySelector('input[type="tel"]');
            if (data.mobile && mobileInput) mobileInput.value = data.mobile;

            // Passport
            if (data.passport && textInputs[2]) textInputs[2].value = data.passport;
            if (data.p_expiry && dateInputs[1]) {
                dateInputs[1].value = data.p_expiry;
                validatePassportExpiry(dateInputs[1]);
            }

            // FFN
            if (data.ffn_number || data.ffn_airline) {
                const ffnToggle = targetBlock.querySelector('.ffn-toggle');
                const ffnFields = targetBlock.querySelector('.ffn-fields');
                const ffnAir = targetBlock.querySelector('.ffn-airline');
                const ffnNum = targetBlock.querySelector('.ffn-number');

                if (ffnToggle) ffnToggle.checked = true;
                if (ffnFields) ffnFields.style.display = 'flex';
                if (ffnAir && data.ffn_airline) ffnAir.value = data.ffn_airline;
                if (ffnNum && data.ffn_number) ffnNum.value = data.ffn_number;
            }

            reorderTravelers();
            updateInventoryStatus();
        } catch (e) {
            console.error("Error populating traveler:", e);
        }

        return targetBlock;
    }

    // 2. Download Sample Template Logic
    window.downloadSampleCSV = function() {
        const headers = ["Title", "First Name", "Last Name", "DOB", "Gender", "Mobile", "Passport", "Expiry", "FFN Airline", "FFN Number"];
        const rows = [
            ["Mr", "Aaryan", "Khan", "1995-05-12", "Male", "9988776655", "Z1234567", "2030-10-10", "6E", "IND6E999"],
            ["Ms", "Zoya", "Akhtar", "1998-08-20", "Female", "8877665544", "X9876543", "2032-12-12", "EK", "EK8877665"],
            ["Mr", "Rahul", "Malhotra", "1990-02-15", "Male", "7766554433", "V5544332", "2029-05-05", "AI", "AI7711223"]
        ];
        const csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(r => r.join(",")).join("\n");
        const link = document.createElement("a");
        link.href = encodeURI(csvContent);
        link.download = "passenger_manifest.csv";
        link.click();
    };

    // 3. Bulk Upload Logic
    window.handleBulkUpload = function(input) {
        if (!input.files || !input.files[0]) return;
        
        const progressDiv = document.getElementById('uploadProgress');
        const bar = document.getElementById('progressBar');
        const percent = document.getElementById('progressPercent');
        
        progressDiv.classList.remove('d-none');
        let width = 0;
        
        const interval = setInterval(() => {
            width += 5;
            bar.style.width = width + '%';
            percent.innerText = width + '%';

            if (width >= 100) {
                clearInterval(interval);
                
                // Mock Data for the list
                const mockData = [
                    { title: 'Mr', first: 'Aaryan', last: 'Khan', dob: '1995-05-12', gender: 'Male', mobile: '9988776655', passport: 'Z1234567', p_expiry: '2030-10-10', ffn_airline: '6E', ffn_number: 'IND6E999' },
                    { title: 'Ms', first: 'Zoya', last: 'Akhtar', dob: '1998-08-20', gender: 'Female', mobile: '8877665544', passport: 'X9876543', p_expiry: '2032-12-12', ffn_airline: 'EK', ffn_number: 'EK8877665' },
                    { title: 'Mr', first: 'Rahul', last: 'Malhotra', dob: '1990-02-15', gender: 'Male', mobile: '7766554433', passport: 'V5544332', p_expiry: '2029-05-05', ffn_airline: 'AI', ffn_number: 'AI7711223' },
                    { title: 'Ms', first: 'Ananya', last: 'Pandey', dob: '1999-11-25', gender: 'Female', mobile: '6655443322', passport: 'N1122334', p_expiry: '2035-01-01', ffn_airline: '6E', ffn_number: 'IND6E888' },
                    { title: 'Mr', first: 'Sumit', last: 'Gupta', dob: '1985-06-30', gender: 'Male', mobile: '9000111222', passport: 'L9988776', p_expiry: '2031-03-03', ffn_airline: 'EK', ffn_number: 'EK9000111' }
                ];
                
                // Add blocks
                mockData.forEach(data => addTravelerWithData(data));
                
                // Clear input so onchange triggers again for same file
                input.value = '';

                setTimeout(() => {
                    progressDiv.classList.add('d-none');
                    Swal.fire({
                        title: 'Success!',
                        text: `${mockData.length} travelers added and auto-allocated to Cabins.`,
                        icon: 'success',
                        timer: 2000,
                        showConfirmButton: false
                    });
                }, 500);
            }
        }, 30);
    };

    // Manual Add
    const addBtn = document.getElementById('addTravelerBtn');
    addBtn.addEventListener('click', () => {
        const nb = addTravelerWithData({ title: 'Mr', first: '', last: '', dob: '', gender: 'Select', mobile: '', passport: '', p_expiry: '' });
        if(nb) nb.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });

    function reorderTravelers() {
        const blocks = document.querySelectorAll('.traveler-block');
        travelerCount = blocks.length;
        blocks.forEach((block, index) => {
            const num = index + 1;
            block.querySelector('h5').firstChild.textContent = `Traveler #${num}`;
        });
    }

    // ─── Passport Expiry Validation ───────────────────────────────────────────
    // Get the travel (departure) date: try URL param "date", then today.
    function getTravelDate() {
        const params = new URLSearchParams(window.location.search);
        // Try common param names used across the app
        const raw = params.get('date') || params.get('departure') || params.get('travel_date') || params.get('depart_date');
        if (raw) {
            const d = new Date(raw);
            if (!isNaN(d.getTime())) return d;
        }
        // Fall back to 6 months from now as a safe default for demo
        const fallback = new Date();
        fallback.setMonth(fallback.getMonth() + 1); // assume travel is ~1 month away
        return fallback;
    }

    window.validatePassportExpiry = function(input) {
        if (!input.value) {
            // Nothing entered yet — reset state
            input.classList.remove('is-invalid-passport');
            const warningEl = input.closest('.col-md-6').querySelector('.passport-warning');
            if (warningEl) warningEl.classList.remove('show');
            return;
        }

        const expiryDate  = new Date(input.value);
        const travelDate  = getTravelDate();

        // Standard rule: passport must be valid for at least 6 months AFTER the travel date
        const minValidDate = new Date(travelDate);
        minValidDate.setMonth(minValidDate.getMonth() + 6);

        const warningEl  = input.closest('.col-md-6').querySelector('.passport-warning');
        const msgEl      = input.closest('.col-md-6').querySelector('.passport-warning-msg');

        if (expiryDate < travelDate) {
            // Passport already expired before travel
            input.classList.add('is-invalid-passport');
            if (msgEl) msgEl.textContent =
                `⚠️ Your passport expires on ${formatDate(expiryDate)}, which is before your travel date (${formatDate(travelDate)}). Most airlines will deny boarding. Please renew your passport.`;
            if (warningEl) warningEl.classList.add('show');
        } else if (expiryDate < minValidDate) {
            // Passport expires within 6 months of travel
            input.classList.add('is-invalid-passport');
            if (msgEl) msgEl.textContent =
                `⚠️ Your passport expires on ${formatDate(expiryDate)}. Many countries require your passport to be valid for at least 6 months beyond your travel date (${formatDate(travelDate)}). You may be denied entry.`;
            if (warningEl) warningEl.classList.add('show');
        } else {
            // All good
            input.classList.remove('is-invalid-passport');
            if (warningEl) warningEl.classList.remove('show');
        }
    };

    function formatDate(d) {
        return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
    }

    window.toggleFFN = function(checkbox) {
        const fields = checkbox.closest('.col-12').querySelector('.ffn-fields');
        if (checkbox.checked) {
            fields.style.display = 'flex';
        } else {
            fields.style.display = 'none';
        }
    }

    // Legacy function removed

    // ──────────────────────────────────────────────────────────────────────────

    // Initial Start
    document.addEventListener('DOMContentLoaded', () => {
        initInventory();
    });
</script>
@endsection
