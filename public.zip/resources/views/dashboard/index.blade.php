@extends('layouts.dashboard')

@section('title', 'My Dashboard | Trip\'Stay')

@section('dashboard_content')
<div class="user-dashboard-index">
    <!-- Welcome Section -->
    <div class="row mb-5 align-items-center">
        <div class="col-lg-8">
            <h1 class="fw-900 text-navy display-6 mb-2">Welcome back, <span class="text-orange">{{ trim(Auth::user()->name) ? Auth::user()->name : 'User' }}!</span></h1>
            <p class="text-muted small fw-bold mb-0">It's a perfect day to plan your next adventure.</p>
        </div>
        <div class="col-lg-4 text-lg-end">
             <div class="d-flex align-items-center justify-content-lg-end gap-3 mt-3 mt-lg-0">
                 <div class="text-end">
                     <h6 class="fw-800 text-navy mb-0">{{ trim(Auth::user()->name) ? Auth::user()->name : 'User' }}</h6>
                     <span class="badge bg-primary rounded-pill small">Member</span>
                 </div>
                 <div class="avatar bg-navy text-white rounded-4 fs-4 d-flex align-items-center justify-content-center fw-bold" style="width: 55px; height: 55px;">
                     {{ trim(Auth::user()->name) ? strtoupper(substr(Auth::user()->name, 0, 1)) : 'U' }}
                 </div>
             </div>
        </div>
    </div>

    <!-- Stats Summary Cards -->
    <div class="row g-4 mb-5">
        @if(Auth::user()->role === 'personal_account' || Auth::user()->role === 'personal')
            <!-- Cargo Specific Stats -->
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0 border-top border-4 border-primary">
                    <div class="stat-badge bg-primary-light"><i class="fas fa-boxes"></i></div>
                    <h6 class="fw-800 text-navy">Total Shipments</h6>
                    <div class="display-6 fw-900 text-navy">00</div>
                    <p class="text-muted small mt-2">All parcels sent till date</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0 border-top border-4 border-info">
                    <div class="stat-badge bg-info-subtle text-info"><i class="fas fa-truck-loading"></i></div>
                    <h6 class="fw-800 text-navy">Active Shipments</h6>
                    <div class="display-6 fw-900 text-navy">00</div>
                    <p class="text-muted small mt-2">Parcels currently in transit</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0 border-top border-4 border-success">
                    <div class="stat-badge bg-success-subtle text-success"><i class="fas fa-check-double"></i></div>
                    <h6 class="fw-800 text-navy">Delivered</h6>
                    <div class="display-6 fw-900 text-navy">00</div>
                    <p class="text-muted small mt-2">Successfully received parcels</p>
                </div>
            </div>
        @else
            <!-- Standard Travel Stats -->
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0">
                    <div class="stat-badge bg-primary-light" style="background: rgba(11, 61, 97, 0.1); color: #0b3d61;"><i class="fas fa-plane-departure"></i></div>
                    <h6 class="fw-800 text-navy">Upcoming Trips</h6>
                    <div class="display-6 fw-900 text-navy">0</div>
                    <p class="text-muted small mt-2">Active upcoming bookings</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0 border-top border-4 border-orange" style="border-top-color: #f97316 !important;">
                    <div class="stat-badge" style="background: rgba(249, 115, 22, 0.1); color: #f97316;"><i class="fas fa-wallet"></i></div>
                    <h6 class="fw-800 text-navy">Wallet Balance</h6>
                    <div class="display-6 fw-900 text-navy">₹{{ isset($wallet) ? number_format($wallet->balance, 2) : '0.00' }}</div>
                    <p class="text-muted small mt-2">Available for quick booking</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="dashboard-card shadow-sm border-0 border-top border-4 border-success" style="border-top-color: #22c55e !important;">
                    <div class="stat-badge" style="background: rgba(34, 197, 94, 0.1); color: #22c55e;"><i class="fas fa-suitcase"></i></div>
                    <h6 class="fw-800 text-navy">Total Bookings</h6>
                    <div class="display-6 fw-900 text-navy">{{ $totalBookings ?? 0 }}</div>
                    <p class="text-muted small mt-2">Lifetime travel experiences</p>
                </div>
            </div>
        @endif
    </div>

    <!-- Recent Activity / Upcoming Trips -->
    <div class="row g-4">
        <div class="col-lg-8">
            <div class="dashboard-card">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-900 text-navy mb-0">Upcoming Bookings</h5>
                    <a href="/dashboard/bookings" class="text-navy small fw-bold text-decoration-none">View All <i class="fas fa-chevron-right ms-1"></i></a>
                </div>
                
                <div class="table-responsive">
                    @if(isset($recentBookings) && count($recentBookings) > 0)
                        <table class="table table-borderless align-middle">
                            <thead class="bg-light">
                                <tr>
                                    <th class="small text-muted fw-bold">Booking ID</th>
                                    <th class="small text-muted fw-bold">Service</th>
                                    <th class="small text-muted fw-bold">Date</th>
                                    <th class="small text-muted fw-bold">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($recentBookings as $booking)
                                <tr>
                                    <td class="fw-bold">{{ $booking->flightBooking->pnr ?? $booking->booking_reference ?? $booking->api_reference ?? 'BKG-'.$booking->id }}</td>
                                    <td>{{ ucfirst($booking->type ?? $booking->booking_type ?? 'Flight') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($booking->created_at)->format('d M Y') }}</td>
                                    <td>
                                        @php
                                            $badgeClass = 'warning';
                                            if($booking->status == 'confirmed' || $booking->status == 'successful') $badgeClass = 'success';
                                            if($booking->status == 'cancelled' || $booking->status == 'failed') $badgeClass = 'danger';
                                        @endphp
                                        <span class="badge bg-{{ $badgeClass }} rounded-pill px-3">{{ ucfirst($booking->status) }}</span>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @else
                        <div class="text-center py-5">
                            <img src="https://img.icons8.com/illustrations/48/empty-box.png" class="mb-3 opacity-50">
                            @if(Auth::user()->role === 'personal_account' || Auth::user()->role === 'personal')
                                <p class="text-muted small fw-bold">You haven't booked any shipments recently.</p>
                                <a href="{{ route('cargo.dashboard.book') }}" class="btn btn-outline-primary btn-sm rounded-pill px-4">Send New Parcel</a>
                            @else
                                <p class="text-muted small fw-bold">You haven't made any bookings yet.</p>
                                <a href="/flights" class="btn btn-outline-primary btn-sm rounded-pill px-4">Find Flights</a>
                            @endif
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="dashboard-card text-center bg-navy" style="background: var(--user-primary) !important; color: #fff;">
                <h5 class="fw-900 mb-3 text-white">Unlock Premium Deals</h5>
                <p class="text-white-50 x-small fw-bold mb-4">Complete your explorer profile to get access to member-only flight discounts and luxury hotel upgrades.</p>
                <div class="profile-progress mx-auto mb-4" style="width: 100px; height: 100px; border: 8px solid rgba(255,255,255,0.1); border-top-color: #f97316; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
                    <span class="fw-900 fs-4">65%</span>
                </div>
                <button class="btn btn-orange w-100 rounded-pill fw-bold" style="background: #f97316; color: #fff; border: none; padding: 12px;">Complete Profile</button>
            </div>
        </div>
    </div>
</div>

<style>
    .x-small { font-size: 11px; }
    .bg-primary-light { background: rgba(11, 61, 97, 0.1); }
</style>
@endsection
