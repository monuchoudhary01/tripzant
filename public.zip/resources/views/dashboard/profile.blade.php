@extends('layouts.dashboard')

@section('title', 'My Profile | Trip\'Stay')

@section('styles')
<style>
    .x-small { font-size: 11px; }
    .doc-upload-preview {
        border: 2px dashed #e2e8f0; border-radius: 12px; padding: 20px; transition: 0.3s; cursor: pointer; text-align: center;
    }
    .doc-upload-preview:hover { border-color: var(--navy); background: #f8fafc; }
</style>
@endsection

@section('dashboard_content')
@php
   $fields = [$user->name, $user->email, $user->phone, $user->address];
   $filled = count(array_filter($fields));
   $completion = round(($filled / count($fields)) * 100);
@endphp

<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <h4 class="fw-900 text-navy mb-1">Account Management</h4>
        <p class="text-muted small mb-0">Manage your personal details for faster bookings.</p>
    </div>
</div>

<div class="row g-4">
    <!-- Main Profile -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <div class="d-flex align-items-center gap-4 mb-4 pb-4 border-bottom border-light">
                <div class="avatar-box bg-navy text-white rounded-circle d-flex align-items-center justify-content-center fw-900 fs-3 shadow-lg" style="width: 80px; height: 80px;">
                    {{ trim($user->name) ? strtoupper(substr($user->name, 0, 1)) : 'U' }}
                </div>
                <div>
                    <h5 class="fw-900 text-navy mb-1">{{ trim($user->name) ? $user->name : 'Traveler' }}</h5>
                    <div class="d-flex gap-3">
                        <span class="x-small fw-bold text-muted"><i class="fas fa-envelope me-1"></i> {{ $user->email }}</span>
                        <span class="x-small fw-bold text-success"><i class="fas fa-check-circle me-1"></i> VERIFIED MEMBER</span>
                    </div>
                </div>
            </div>

            <h6 class="fw-900 text-navy mb-4"><i class="fas fa-user-pen me-2 text-primary"></i> Personal Details</h6>
            <form class="row g-3" method="POST" action="{{ route('dashboard.profile.update') }}">
                @csrf
                <div class="col-md-12">
                    <label class="form-label x-small fw-bold text-muted uppercase">Full Name</label>
                    <input type="text" name="name" class="form-control rounded-3" value="{{ old('name', $user->name) }}" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label x-small fw-bold text-muted uppercase">Email Address</label>
                    <input type="email" class="form-control rounded-3" value="{{ $user->email }}" disabled readonly>
                </div>
                <div class="col-md-6">
                    <label class="form-label x-small fw-bold text-muted uppercase">Phone (Calling)</label>
                    <input type="text" name="phone" class="form-control rounded-3" value="{{ old('phone', $user->phone) }}">
                </div>
                <div class="col-12">
                    <label class="form-label x-small fw-bold text-muted uppercase">Full Residential Address</label>
                    <textarea name="address" class="form-control rounded-3" rows="2">{{ old('address', $user->address) }}</textarea>
                </div>
                
                <div class="col-12 mt-5">
                    <button type="submit" class="btn btn-navy py-3 px-5 rounded-pill fw-900 shadow-sm">SAVE PROFILE UPDATES</button>
                    <span class="ms-3 text-muted x-small fw-bold"><i class="fas fa-lock me-1"></i> Changes are saved securely</span>
                </div>
            </form>
        </div>
    </div>

    <!-- Sidebar Stats/Info -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4" style="background: linear-gradient(135deg, var(--user-primary), #001f3f); color: #fff;">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h6 class="fw-900 mb-0">Booking Efficiency</h6>
                <i class="fas fa-chart-line opacity-50"></i>
            </div>
            <div class="mb-4">
                <div class="h1 fw-900 mb-1">{{ $completion }}%</div>
                <div class="small opacity-75 fw-bold">Profile Completion</div>
            </div>
            <div class="progress bg-white bg-opacity-10 rounded-pill mb-3" style="height: 6px;">
                <div class="progress-bar bg-warning" style="width: {{ $completion }}%;"></div>
            </div>
            @if($completion < 100)
            <p class="x-small fw-bold opacity-75">Complete your profile to unlock instant 1-click bookings.</p>
            @else
            <p class="x-small fw-bold text-success opacity-100">Your profile is ready for instant 1-click bookings!</p>
            @endif
        </div>
    </div>
</div>

@push('scripts')
<script>
    @if(session('success'))
    Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: '{{ session("success") }}',
        timer: 3000,
        showConfirmButton: false
    });
    @endif
    @if($errors->any())
    Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: '{{ collect($errors->all())->implode(', ') }}',
    });
    @endif
</script>
@endpush
@endsection
