@extends('layouts.dashboard')

@section('title', "Tripzant Wallet - My Balance | Trip Zant")

@section('styles')
<style>
    .wallet-card-main {
        background: linear-gradient(135deg, var(--navy), #001f3f);
        border-radius: 24px; color: #fff; padding: 40px;
        position: relative; overflow: hidden;
        box-shadow: 0 20px 40px rgba(11, 61, 97, 0.2);
    }
    .wallet-card-main::before {
        content: ''; position: absolute; top: -50px; right: -50px;
        width: 200px; height: 200px; background: rgba(255,255,255,0.05);
        border-radius: 50%;
    }
    .transaction-row {
        padding: 15px; border-radius: 15px; transition: 0.3s;
        border: 1px solid #f1f5f9; margin-bottom: 12px;
    }
    .transaction-row:hover { background: #f8fafc; border-color: var(--primary); }
</style>
@endsection

@section('dashboard_content')
<div class="row g-4 justify-content-center">
    <div class="col-lg-10">
        <div class="wallet-card-main mb-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="fw-700 opacity-75 mb-0">TOTAL BALANCE</h5>
                <img src="/img/logo.svg" height="30" style="filter: brightness(0) invert(1);">
            </div>
            <h1 class="display-4 fw-900 mb-2">₹{{ number_format($wallet->balance ?? 0, 2) }}</h1>
            @if(($wallet->balance ?? 0) <= 0)
                <p class="x-small fw-bold text-white-50 mb-0"><i class="fas fa-info-circle me-1"></i> Your wallet is empty. Credits will appear here when you receive refunds or bonuses.</p>
            @endif
        </div>

        <h5 class="fw-900 text-navy mb-4">Recent Transactions</h5>
        <div class="card border-0 shadow-sm rounded-4 p-4">
            @forelse($transactions as $t)
            <div class="transaction-row d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div class="icon-box-sm rounded-circle d-flex align-items-center justify-content-center" style="width:45px; height:45px; background: {{ $t->type == 'credit' ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)' }}; color: {{ $t->type == 'credit' ? '#22c55e' : '#ef4444' }};">
                        <i class="fas {{ $t->type == 'credit' ? 'fa-arrow-down' : 'fa-arrow-up' }}"></i>
                    </div>
                    <div>
                        <h6 class="fw-800 text-navy mb-0">{{ $t->description ?? $t->remark ?? 'Transaction' }}</h6>
                        <span class="x-small text-muted fw-bold">{{ $t->created_at->format('d M Y') }}</span>
                    </div>
                </div>
                <div class="text-end">
                    <h6 class="fw-900 mb-0 {{ $t->type == 'credit' ? 'text-success' : 'text-danger' }}">{{ $t->type == 'credit' ? '+' : '-' }}₹{{ number_format($t->amount, 2) }}</h6>
                    <span class="badge bg-light text-muted x-small fw-bold">{{ ucfirst($t->status) }}</span>
                </div>
            </div>
            @empty
            <div class="text-center py-5">
                <i class="fas fa-history fa-3x text-muted opacity-25 mb-3"></i>
                <p class="text-muted small fw-bold">No transaction history found.</p>
            </div>
            @endforelse
            @if($transactions->count() > 0)
            <button class="btn btn-link text-navy fw-900 small w-100 mt-3 text-decoration-none">VIEW ALL TRANSACTIONS</button>
            @endif
        </div>
    </div>
</div>
@endsection
