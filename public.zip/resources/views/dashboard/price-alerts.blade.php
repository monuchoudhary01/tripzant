@extends('layouts.dashboard')

@section('title', 'Fare Monitoring & Price Alerts | Trip\'Stay')

@section('dashboard_content')
<div class="price-alerts-page">
    <div class="row mb-5 justify-content-between align-items-center">
        <div class="col-lg-6">
            <h4 class="fw-900 text-navy mb-1">Fare Monitoring</h4>
            <p class="text-muted small">We are tracking prices for you. Book when the price is right.</p>
        </div>
        <div class="col-lg-auto">
            <button class="btn btn-navy rounded-pill px-4 fw-bold small" data-bs-toggle="modal" data-bs-target="#newAlertModal"><i class="fas fa-plus me-2"></i> Track New Route</button>
        </div>
    </div>

    <div class="row g-4">


        @forelse($alerts as $alert)
            @php
                $isDropped = ($alert->matched_data['price'] ?? 1000000) < $alert->target_price;
                $currentPrice = $alert->matched_data['price'] ?? '--';
                $oldPrice = $alert->matched_data['previous_price'] ?? null;
            @endphp
            <div class="col-12">
                <div class="dashboard-card border-0 shadow-sm p-0 overflow-hidden position-relative {{ $isDropped ? 'border-start border-5 border-success' : '' }}">
                    @if($isDropped)
                        <div class="alert-fire-bg"></div>
                    @endif
                    
                    <div class="p-4 position-relative" style="z-index: 2;">
                        <div class="row align-items-center">
                            <div class="col-lg-4">
                                <div class="d-flex align-items-center gap-3">
                                    <div class="p-3 bg-light rounded-circle text-navy fs-4"><i class="fas fa-plane-departure"></i></div>
                                    <div>
                                        <h5 class="fw-900 text-navy mb-0 fs-6">{{ $alert->origin }} → {{ $alert->destination }}</h5>
                                        <p class="text-muted x-small fw-bold mb-0"><i class="far fa-calendar-alt me-1"></i> {{ $alert->travel_date->format('d M, Y') }}</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 text-center text-lg-start">
                                <span class="text-muted x-small fw-bold d-block mb-1">CURRENT PRICE</span>
                                @if($oldPrice)
                                    <span class="text-decoration-line-through text-muted small me-2">₹{{ number_format($oldPrice) }}</span>
                                    <span class="fw-900 text-success fs-4">₹{{ number_format($currentPrice) }}</span>
                                @else
                                    <span class="fw-900 text-navy fs-4">₹{{ $currentPrice != '--' ? '₹'.number_format($currentPrice) : '--' }}</span>
                                @endif
                            </div>
                            <div class="col-lg-2 text-center text-lg-start">
                                <span class="text-muted x-small fw-bold d-block mb-1">STATUS</span>
                                @if($isDropped)
                                    <span class="badge rounded-pill bg-success px-3 py-2 fw-900 pulse-alert"><i class="fas fa-fire me-1"></i> PRICE DROPPED!</span>
                                @else
                                    <span class="badge rounded-pill bg-light text-navy px-3 py-2 border fw-bold tracking-badge"><i class="fas fa-radar fa-spin me-1" style="animation: fa-spin 5s linear infinite;"></i> TRACKING</span>
                                @endif
                            </div>
                            <div class="col-lg-3 text-end d-flex gap-2 justify-content-end">
                                <button class="btn btn-outline-navy rounded-pill px-3 fw-bold x-small">Details</button>
                                <button class="btn btn-navy rounded-pill px-4 fw-bold x-small">Book Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12 mt-5 p-5 bg-white rounded-5 shadow-sm text-center border-dashed">
                <div class="fs-1 text-muted opacity-25 mb-3"><i class="fas fa-bell-slash"></i></div>
                <h5 class="fw-900 text-navy">No active alerts.</h5>
                <p class="text-muted small">Start tracking flight routes to get real-time price drop notifications.</p>
                <button class="btn btn-navy rounded-pill px-4 mt-3 fw-bold" data-bs-toggle="modal" data-bs-target="#newAlertModal">Set Your First Alert</button>
            </div>
        @endforelse
    </div>


</div>

<!-- Track New Alert Modal -->
<div class="modal fade" id="newAlertModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <div class="modal-header bg-navy text-white p-4">
                <h5 class="fw-900 mb-0">Set New Fare Monitor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label x-small fw-bold text-muted">ROUTE</label>
                        <input type="text" class="form-control fw-bold" placeholder="e.g. Delhi to Dubai" value="Delhi (DEL) → Dubai (DXB)">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label x-small fw-bold text-muted">TRAVEL DATE</label>
                        <input type="date" class="form-control fw-bold" value="2026-04-14">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label x-small fw-bold text-muted">TARGET PRICE (MAX)</label>
                        <div class="input-group">
                            <span class="input-group-text bg-light fw-bold small">₹</span>
                            <input type="number" class="form-control fw-bold" placeholder="e.g. 20000">
                        </div>
                    </div>
                    <div class="col-12">
                        <label class="form-label x-small fw-bold text-muted mb-2 d-block">NOTIFICATION PREFERENCES</label>
                        <div class="d-flex gap-4">
                            <div class="form-check"><input class="form-check-input" type="checkbox" checked><label class="form-check-label small fw-bold">Email</label></div>
                            <div class="form-check"><input class="form-check-input" type="checkbox" checked><label class="form-check-label small fw-bold">WhatsApp</label></div>
                        </div>
                    </div>
                    <div class="col-12 mt-4">
                        <button class="btn btn-navy w-100 rounded-pill py-3 fw-bold shadow-sm" data-bs-dismiss="modal">START TRACKING <i class="fas fa-radar ms-2"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .alert-fire-bg {
        position: absolute;
        top: 0; right: 0; bottom: 0; left: 0;
        background: linear-gradient(90deg, transparent 70%, rgba(34, 197, 94, 0.05) 100%);
        pointer-events: none;
    }
    .pulse-alert {
        box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.4);
        animation: pulse-green 2s infinite;
    }
    @keyframes pulse-green {
        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7); }
        70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(34, 197, 94, 0); }
        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); }
    }
    .x-small { font-size: 11px; }
    .tracking-badge { background: rgba(11, 61, 97, 0.05); color: #0b3d61; border: 1px solid #e2e8f0; }
    .dashboard-card { transition: all 0.3s ease; height: auto !important; }
    .dashboard-card:hover { transform: translateY(-3px); box-shadow: 0 15px 35px rgba(0,0,0,0.08) !important; }
</style>
@endsection
