@extends('layouts.dashboard')

@section('title', 'My Wishlist | Trip\'Stay')

@section('dashboard_content')
<div class="wishlist-page">
    <div class="row mb-4">
        <div class="col-12 text-center text-lg-start">
            <h4 class="fw-900 text-navy mb-1">My Wishlist</h4>
            <p class="text-muted small">Your saved flights, hotels, and tour packages.</p>
        </div>
    </div>

    <!-- Category Pills -->
    <div class="row mb-5 justify-content-center justify-content-lg-start">
        <div class="col-auto">
            <div class="d-flex gap-2">
                <button class="btn btn-navy rounded-pill px-4 fw-bold small">All Items ({{ $wishlistItems->count() }})</button>
                <button class="btn btn-outline-navy rounded-pill px-4 fw-bold small">Hotels ({{ $wishlistItems->where('item_type', 'Hotel')->count() }})</button>
                <button class="btn btn-outline-navy rounded-pill px-4 fw-bold small">Flights ({{ $wishlistItems->where('item_type', 'Flight')->count() }})</button>
                <button class="btn btn-outline-navy rounded-pill px-4 fw-bold small">Tours ({{ $wishlistItems->where('item_type', 'Tour')->count() }})</button>
            </div>
        </div>
    </div>

    <div class="row g-4">
        @forelse($wishlistItems as $item)
        <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="dashboard-card p-0 overflow-hidden border-0 shadow-sm hvr-grow rounded-4 bg-white" style="transition: all 0.3s ease;">
                <div class="position-relative">
                    <img src="{{ $item->item_image ?? 'https://via.placeholder.com/500x300?text='.urlencode($item->item_name) }}" class="w-100" style="height: 180px; object-fit: cover;">
                    <form action="#" method="POST" class="position-absolute top-0 end-0 m-2">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger rounded-circle shadow-sm d-flex align-items-center justify-content-center" style="width: 32px; height: 32px; font-size: 14px;"><i class="fas fa-heart fs-6"></i></button>
                    </form>
                    <div class="badge bg-white text-navy position-absolute bottom-0 start-0 m-2 px-3 py-1 rounded-pill fw-bold x-small shadow-sm">{{ ucfirst($item->item_type) }}</div>
                </div>
                <div class="p-3">
                    <h6 class="fw-900 text-navy mb-1" style="font-size: 14px;">{{ $item->item_name }}</h6>
                    <p class="text-muted small mb-3 fw-bold x-small"><i class="fas fa-map-marker-alt me-1"></i> {{ $item->item_location ?? 'Global' }}</p>
                    <div class="d-flex justify-content-between align-items-center">
                        <div class="fw-900 text-navy fs-5">₹{{ number_format($item->item_price, 2) }} <span class="fw-bold x-small text-muted">/ starting</span></div>
                        <a href="#" class="btn btn-outline-navy rounded-pill p-2 fs-6 d-flex align-items-center justify-content-center" style="width: 35px; height: 35px;"><i class="fas fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
        @empty
        <div class="col-12 text-center py-5">
            <div class="mb-4">
                <i class="fas fa-heart-broken display-1 text-muted opacity-25"></i>
            </div>
            <h5 class="fw-900 text-navy">Wishlist is Empty</h5>
            <p class="text-muted small">You haven't saved any travel deals yet. Start exploring and save your favorites here!</p>
            <a href="/" class="btn btn-navy rounded-pill px-5 mt-3 fw-bold">Explore Now</a>
        </div>
        @endforelse
    </div>
</div>

<style>
    .x-small { font-size: 11px; }
</style>
@endsection
