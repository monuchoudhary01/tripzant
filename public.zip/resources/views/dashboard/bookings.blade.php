@extends('layouts.dashboard')

@section('title', 'My Trips | Tripzant')

@section('styles')
<style>
    :root {
        --trip-blue: #005eb8;
        --trip-dark: #003366;
    }

    body {
        background-color: #f8fafc !important;
        font-family: 'Outfit', sans-serif;
    }

    .trip-card-pro {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 20px;
        padding: 25px;
        margin-bottom: 25px;
        transition: 0.3s;
    }
    .trip-card-pro:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0,0,0,0.05);
    }

    .pnr-badge {
        background: #eff6ff;
        color: var(--trip-blue);
        padding: 5px 15px;
        border-radius: 8px;
        font-weight: 900;
        letter-spacing: 1px;
    }

    .status-confirmed {
        color: #10b981;
        background: #f0fdf4;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 800;
    }

    .sidebar-nav-pro {
        background: white;
        border-radius: 20px;
        padding: 20px;
        position: sticky;
        top: 20px;
    }
    .sidebar-link {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 20px;
        border-radius: 12px;
        color: #64748b;
        font-weight: 700;
        text-decoration: none;
        transition: 0.2s;
    }
    .sidebar-link:hover, .sidebar-link.active {
        background: var(--trip-blue);
        color: white;
    }
</style>
@endsection

@section('dashboard_content')
<div class="user-bookings-wrap">
    <div class="d-flex justify-content-between align-items-end mb-4">
        <div>
            <h3 class="fw-900 text-navy mb-1">My Bookings</h3>
            <p class="text-muted small">View, manage, and download tickets for your upcoming trips.</p>
        </div>
        <div class="small fw-bold">Showing Latest 5</div>
    </div>

    <div id="bookingList">
        @forelse($bookings as $booking)
            @php
                $fb = $booking->flightBooking;
                $details = is_string($booking->api_booking_details) ? json_decode($booking->api_booking_details, true) : $booking->api_booking_details;
                // Fallback for older data or other types
                $details = $details ?? (is_string($booking->booking_details) ? json_decode($booking->booking_details, true) : $booking->booking_details);
                
                $type = $booking->type ?? $booking->booking_type ?? 'flight';
                
                $origin = $fb->origin ?? $details['origin'] ?? $details['flight']['itineraries'][0]['segments'][0]['departure']['iataCode'] ?? 'TRZ';
                $destination = $fb->destination ?? $details['destination'] ?? 'LOC';
                
                $airline = $fb->airline_code ?? $details['flight']['airline'] ?? ($type == 'flight' ? 'Flt-'.$booking->id : ucfirst($type));
                $flightNum = isset($fb->flight_number) ? $fb->airline_code.$fb->flight_number : ($details['flight']['flight_number'] ?? '');
                
                $statusColor = '#f97316';
                $statusBg = '#fff7ed';
                if($booking->status == 'confirmed' || $booking->status == 'successful') {
                    $statusColor = '#10b981';
                    $statusBg = '#f0fdf4';
                }
            @endphp
            <!-- Trip Card -->
            <div class="trip-card-pro">
                <div class="row align-items-center">
                    <div class="col-6">
                        <span class="pnr-badge small">{{ $fb->pnr ?? $booking->booking_reference ?? $booking->api_reference ?? 'REF-'.$booking->id }}</span>
                        <span class="status-confirmed ms-3" style="background: {{ $statusBg }}; color: {{ $statusColor }};">
                            <i class="fas {{ $booking->status == 'confirmed' ? 'fa-check' : 'fa-clock' }} me-1"></i> {{ strtoupper($booking->status) }}
                        </span>
                    </div>
                    <div class="col-6 text-end text-muted small fw-bold">
                        Booked on: {{ $booking->created_at->format('M d, Y') }}
                    </div>
                </div>
                
                <div class="row mt-4 align-items-center">
                    <div class="col-md-3">
                        <h4 class="fw-900 mb-0">{{ $origin }}</h4>
                        <div class="small fw-700 text-muted">{{ $fb->origin_city ?? 'Origin' }}</div>
                    </div>
                    <div class="col-md-4 text-center">
                        <div class="duration small fw-700 text-muted mb-2">{{ $details['duration'] ?? '--' }}</div>
                        <div class="d-flex align-items-center gap-2">
                            <div style="height:1px; background:#e2e8f0; flex:1;"></div>
                            <i class="fas {{ $type == 'flight' ? 'fa-plane' : ($type == 'hotel' ? 'fa-hotel' : 'fa-suitcase-rolling') }} text-primary"></i>
                            <div style="height:1px; background:#e2e8f0; flex:1;"></div>
                        </div>
                        <div class="small fw-bold text-success mt-2">{{ $airline }} {{ $flightNum }} ({{ $fb->cabin_class ?? 'Economy' }})</div>
                    </div>
                    <div class="col-md-3">
                        <h4 class="fw-900 mb-0">{{ $destination }}</h4>
                        <div class="small fw-700 text-muted">{{ $fb->destination_city ?? 'Destination' }}</div>
                    </div>
                    <div class="col-md-2 text-end">
                        <div class="fw-900 fs-5 text-navy">₹{{ number_format($booking->total_amount ?? $booking->selling_price ?? 0, 2) }}</div>
                    </div>
                </div>

                <div class="mt-4 pt-4 border-top d-flex justify-content-between align-items-center">
                    <div class="d-flex gap-3 align-items-center">
                        <div class="small fw-bold text-muted"><i class="fas fa-tag me-1"></i> {{ ucfirst($type) }} Booking</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button class="btn btn-sm btn-light border fw-900 rounded-pill px-3" onclick="viewTicket('{{ $fb->pnr ?? $booking->booking_reference }}')">VIEW DETAILS</button>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-light border fw-900 rounded-pill px-3 dropdown-toggle" data-bs-toggle="dropdown">MANAGE</button>
                            <ul class="dropdown-menu shadow-sm border-0 rounded-4 p-2">
                                <li><a class="dropdown-item small fw-bold" href="#"><i class="fas fa-edit me-2"></i> RESCHEDULE</a></li>
                                <li><a class="dropdown-item small fw-bold text-danger" href="#"><i class="fas fa-times me-2"></i> CANCEL</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        @empty
            <div class="text-center py-5 bg-white rounded-4 border shadow-sm">
                <div class="mb-4">
                    <i class="fas fa-suitcase-rolling display-4 text-muted opacity-25"></i>
                </div>
                <h5 class="fw-900 text-navy">No Trips Found</h5>
                <p class="text-muted small px-5">It looks like you haven't booked any trips yet. Exploring new destinations is just a click away!</p>
                <a href="/" class="btn btn-navy rounded-pill px-5 py-2 mt-3 fw-bold">Plan a Trip</a>
            </div>
        @endforelse

        @if($bookings->count() > 0)
        <div class="text-center py-4">
            <p class="text-muted small">Only upcoming trips are shown. For past trips, please check your email archive.</p>
        </div>
        @endif
    </div>
</div>
@endsection

@section('scripts')
<script>
    function viewTicket(pnr) {
        Swal.fire({
            title: 'Generating E-Ticket...',
            text: `Allocating seat manifest for PNR: ${pnr}`,
            timer: 1500,
            showConfirmButton: false,
            didOpen: () => { Swal.showLoading(); }
        }).then(() => {
            window.location.href = '/booking-confirmation';
        });
    }
</script>
@endsection
